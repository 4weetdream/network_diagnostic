#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
==========================================================================
手机端轻量网络卡顿自查检测软件
Lightweight Mobile Network Lag Diagnostic Tool

功能:
  - 实时测速 (下载/上传)
  - Ping 网关/公共 DNS 延迟
  - 数据包丢包率 & 网络抖动分析
  - WiFi 信号强度 & 信道拥挤度
  - 蜂窝网络信号 & 连接状态
  - 后台 APP 带宽占用扫描
  - 智能故障诊断 + 一键解决建议
  - 图文诊断报告生成

技术栈:
  - Python 3.8+
  - Kivy + KivyMD (跨平台移动 UI)
  - 系统网络命令 (ping, netstat, iwconfig)
  - 纯 Python 实现，无外部 C 依赖

运行方式:
  # 桌面端开发调试
  python main.py

  # Android 部署 (Buildozer)
  buildozer android debug deploy run

  # iOS 部署 (kivy-ios)
  python -m toolchain build python3 kivy
  xcodebuild ...

作者: Network Diagnostic Team
许可: MIT
==========================================================================
"""

import os
import sys
import threading
import webbrowser
from typing import Optional

# ============================================================
# Kivy 导入 - 需要先设置环境变量
# ============================================================
os.environ["KIVY_NO_ARGS"] = "1"

from kivy.config import Config

# 移动端优化配置: 小屏幕、全触摸
Config.set("graphics", "width", "400")
Config.set("graphics", "height", "780")
Config.set("graphics", "resizable", False)
Config.set("input", "mouse", "mouse,disable_multitouch")
Config.set("kivy", "exit_on_escape", "1")

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.clock import Clock
from kivy.properties import StringProperty, NumericProperty
from kivy.core.window import Window

# KivyMD Material Design
try:
    from kivymd.app import MDApp
    from kivymd.uix.button import MDRaisedButton
    from kivymd.uix.dialog import MDDialog
    use_kivymd = True
except ImportError:
    use_kivymd = False
    print("[UI] KivyMD 未安装，回退到纯 Kivy 模式")

# ============================================================
# 核心检测模块导入
# ============================================================
# 将项目根目录加入路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.orchestrator import TestOrchestrator
from core.diagnosis_engine import DIAGNOSIS_DIMENSIONS
from core.report_generator import generate_html_report, save_report


# ============================================================
# 屏幕定义
# ============================================================
class MainScreen(Screen):
    """主界面 - 功能入口"""
    pass


class TestScreen(Screen):
    """检测进行中界面"""
    pass


class ReportScreen(Screen):
    """检测报告结果界面"""
    pass


# ============================================================
# 移动端网络诊断主应用
# ============================================================
class NetworkDiagApp(MDApp if use_kivymd else App):
    """
    主应用程序类

    管理:
      - 屏幕切换 (Main → Test → Report)
      - 检测流程编排 (通过 TestOrchestrator)
      - 结果展示与报告
    """

    # 主题色 - 靛蓝渐变
    primary_color = (0.4, 0.49, 0.92, 1.0)  # #667eea

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.title = "网络诊断工具"

        # 检测编排器
        self.orchestrator = TestOrchestrator()
        self.orchestrator.set_progress_callback(self._on_progress)
        self.orchestrator.set_phase_callback(self._on_phase)

        # 检测线程 (后台运行)
        self.test_thread: Optional[threading.Thread] = None
        self.is_testing = False

        # 诊断结果缓存
        self.diagnosis_result = None
        self.report_path = ""

    def build(self):
        """
        构建 UI 界面

        从 .kv 文件加载布局，设置屏幕管理器。
        """
        self.theme_cls.primary_palette = "Indigo"
        self.theme_cls.theme_style = "Light"

        # 屏幕管理器
        sm = ScreenManager()
        sm.add_widget(MainScreen(name="main"))
        sm.add_widget(TestScreen(name="test"))
        sm.add_widget(ReportScreen(name="report"))

        return sm

    # ============================================================
    # 屏幕切换
    # ============================================================
    def go_home(self):
        """返回主界面"""
        self.root.current = "main"

    def _switch_to(self, screen_name: str):
        """安全切换屏幕"""
        Clock.schedule_once(lambda dt: setattr(self.root, "current", screen_name))

    # ============================================================
    # 检测流程控制
    # ============================================================
    def start_full_test(self):
        """开始完整检测（主界面入口）"""
        if self.is_testing:
            print("[App] 检测已在运行中")
            return

        self._switch_to("test")
        self._reset_test_ui()
        self.is_testing = True

        # 后台线程执行检测
        self.test_thread = threading.Thread(target=self._run_test, daemon=True)
        self.test_thread.start()

    def _run_test(self):
        """后台执行检测流程 (在非 UI 线程运行)"""
        try:
            # 执行全部检测
            result = self.orchestrator.run_all()

            # 保存结果
            self.diagnosis_result = result.get("diagnosis")
            self.report_path = result.get("report_path", "")

            # 切到结果页
            if self.diagnosis_result:
                Clock.schedule_once(lambda dt: self._display_report(), 0.3)
            else:
                self._show_error(result.get("error", "检测失败"))

        except Exception as e:
            print(f"[App] 检测异常: {e}")
            import traceback
            traceback.print_exc()
            self._show_error(str(e))

        finally:
            self.is_testing = False

    def quick_test(self, test_type: str):
        """
        快捷单项检测

        Args:
            test_type: "ping" / "signal" / "speed" / "bandwidth"
        """
        if self.is_testing:
            return

        self._switch_to("test")
        self._reset_test_ui()
        self.is_testing = True

        # 通过新增 quick test 方法来支持单项测试
        self.test_thread = threading.Thread(
            target=self._run_quick_test, args=(test_type,), daemon=True
        )
        self.test_thread.start()

    def _run_quick_test(self, test_type: str):
        """后台执行单项检测"""
        try:
            phase_map = {
                "ping": ("ping", self.orchestrator.run_phase_ping),
                "signal": ("signal", self.orchestrator.run_phase_signal),
                "speed": ("speed", self.orchestrator.run_phase_speed),
                "bandwidth": ("bandwidth", self.orchestrator.run_phase_bandwidth),
            }

            if test_type not in phase_map:
                raise ValueError(f"未知检测类型: {test_type}")

            _, func = phase_map[test_type]
            Clock.schedule_once(lambda dt: self._update_label(
                "progress_label", f"正在执行{test_type}检测..."))

            func()

            # 单项检测也尝试诊断（只有部分数据）
            self.orchestrator.run_phase_diagnose()
            self.diagnosis_result = self.orchestrator.diagnosis_result
            self.report_path = self.orchestrator.run_phase_report()

            if self.diagnosis_result:
                Clock.schedule_once(lambda dt: self._display_report(), 0.3)

        except Exception as e:
            print(f"[App] 单项检测异常: {e}")
            self._show_error(str(e))
        finally:
            self.is_testing = False

    def stop_test(self):
        """停止正在进行的检测"""
        if self.is_testing:
            self.orchestrator.stop()
            self.is_testing = False
            self._show_error("用户取消检测")

    def restart_test(self):
        """重新检测"""
        self.go_home()
        # 延迟一下再开始
        Clock.schedule_once(lambda dt: self.start_full_test(), 0.5)

    # ============================================================
    # UI 更新 (从 UI 线程调用)
    # ============================================================
    def _on_progress(self, pct: float, phase: str, status: str):
        """
        进度回调 - 由编排器在检测线程调用

        Args:
            pct: 整体进度百分比
            phase: 当前阶段名 (ping/signal/speed/bandwidth/diagnose/report)
            status: 状态文本
        """
        Clock.schedule_once(lambda dt: self._update_progress_ui(pct, phase, status))

    def _update_progress_ui(self, pct: float, phase: str, status: str):
        """更新测试界面进度显示"""
        screens = self.root.screens
        test_screen = [s for s in screens if s.name == "test"]
        if not test_screen:
            return

        test_screen = test_screen[0]

        # 更新总进度条
        progress_bar = test_screen.ids.get("overall_progress")
        if progress_bar:
            progress_bar.value = pct

        # 更新进度文本
        label = test_screen.ids.get("progress_label")
        if label:
            phase_names = {
                "ping": "延迟检测", "signal": "信号检测",
                "speed": "网速测试", "bandwidth": "带宽扫描",
                "diagnose": "综合诊断", "report": "生成报告",
            }
            label.text = f"📌 {phase_names.get(phase, phase)} ({int(pct)}%)"

        detail = test_screen.ids.get("progress_detail")
        if detail:
            detail.text = status

    def _on_phase(self, phase: str):
        """阶段变更回调 - 更新各单项状态"""
        Clock.schedule_once(lambda dt: self._update_phase_status(phase))

    def _update_phase_status(self, active_phase: str):
        """更新测试界面中各单项的状态指示灯"""
        phases = {
            "ping": "ping_status",
            "signal": "signal_status",
            "speed": "speed_status",
            "bandwidth": "bw_status",
            "diagnose": "diag_status",
        }

        for pname, id_name in phases.items():
            screen = [s for s in self.root.screens if s.name == "test"]
            if not screen:
                return
            label = screen[0].ids.get(id_name)
            if not label:
                continue

            if pname == active_phase:
                label.text = "🔄 检测中..."
                label.color = (0.4, 0.49, 0.92, 1)
            elif self._is_phase_done(pname, active_phase):
                label.text = "✅ 完成"
                label.color = (0.16, 0.65, 0.22, 1)
            else:
                label.text = "⏳ 等待..."
                label.color = (0.6, 0.6, 0.6, 1)

    def _is_phase_done(self, phase: str, active: str) -> bool:
        """判断阶段是否已完成"""
        order = ["ping", "signal", "speed", "bandwidth", "diagnose", "report"]
        if phase not in order:
            return False
        phase_idx = order.index(phase)
        active_idx = order.index(active) if active in order else -1
        return phase_idx < active_idx

    def _update_label(self, id_name: str, text: str):
        """更新指定 ID 的标签文本"""
        screen = self.root.current_screen
        if screen and id_name in screen.ids:
            screen.ids[id_name].text = text

    def _reset_test_ui(self):
        """重置测试界面状态"""
        screen = [s for s in self.root.screens if s.name == "test"]
        if not screen:
            return
        test = screen[0]

        test.ids.get("overall_progress", object()).value = 0
        test.ids.get("progress_label", object()).text = "正在准备检测..."
        test.ids.get("progress_detail", object()).text = ""

        for id_name in ["ping_status", "signal_status", "speed_status",
                         "bw_status", "diag_status"]:
            lbl = test.ids.get(id_name)
            if lbl:
                lbl.text = "⏳ 等待..."
                lbl.color = (0.6, 0.6, 0.6, 1)

    # ============================================================
    # 报告展示
    # ============================================================
    def _display_report(self):
        """在报告页显示诊断结果"""
        diagnosis = self.diagnosis_result
        if not diagnosis:
            self._show_error("无诊断数据")
            return

        self._switch_to("report")
        screen = [s for s in self.root.screens if s.name == "report"]
        if not screen:
            return
        report = screen[0]

        # 综合评分
        score = diagnosis.get("overall_score", 0)
        health = diagnosis.get("overall_health", "未知")
        desc = diagnosis.get("overall_health_desc", "")

        report.ids.get("score_label", object()).text = str(score)
        report.ids.get("health_label", object()).text = f"健康度: {health}"

        # 健康度颜色
        color_map = {
            "优秀": (0.16, 0.65, 0.22, 1),
            "良好": (0.2, 0.5, 0.9, 1),
            "一般": (0.9, 0.6, 0.1, 1),
            "较差": (0.9, 0.3, 0.2, 1),
            "极差": (0.7, 0.1, 0.1, 1),
        }
        color = color_map.get(health, (0.4, 0.49, 0.92, 1))
        report.ids.get("score_label", object()).color = color
        report.ids.get("health_desc", object()).text = desc

        # 测速结果
        ns = diagnosis.get("network_summary", {})
        report.ids.get("dl_speed", object()).text = f"{ns.get('download_mbps', 0):.1f} Mbps"
        report.ids.get("ul_speed", object()).text = f"{ns.get('upload_mbps', 0):.2f} Mbps"

        # Ping 结果
        report.ids.get("ping_delay", object()).text = f"{ns.get('avg_latency_ms', 0):.0f} ms"
        jitter = max(p.get("jitter_ms", 0) for p in
                     diagnosis.get("problems", [])
                     if p["dimension"] == "carrier_fluctuation") or 0
        report.ids.get("ping_jitter", object()).text = f"{jitter:.0f} ms"
        loss = max(p.get("evidence", {}).get("loss_rate_pct", 0) for p in
                   diagnosis.get("problems", [])
                   if p["dimension"] == "packet_loss") or 0
        report.ids.get("ping_loss", object()).text = f"{loss:.0f}%"

        # 信号强度
        signal_pct = ns.get("signal_pct", 0)
        slider = report.ids.get("signal_slider")
        if slider:
            slider.value = signal_pct
        pct_label = report.ids.get("signal_pct_label")
        if pct_label:
            pct_label.text = f"{signal_pct}%"

        # 问题列表
        problems = diagnosis.get("problems", [])
        problem_text = ""
        if problems:
            for p in problems[:4]:  # 最多显示 4 个
                dim_info = DIAGNOSIS_DIMENSIONS.get(p["dimension"], {})
                icon = dim_info.get("icon", "⚠")
                problem_text += f"{icon} {dim_info.get('name', p['dimension'])}\n"
        else:
            problem_text = "✅ 未发现明显问题"

        report.ids.get("problem_list", object()).text = problem_text.strip()

        # 修复建议
        suggestions = diagnosis.get("fix_suggestions", [])
        fix_text = ""
        if suggestions:
            for s in suggestions[:4]:
                fix_text += f"🔧 {s.get('action', '')}: {s.get('expected_effect', '')}\n"
        else:
            fix_text = "✅ 无需修复"

        report.ids.get("fix_list", object()).text = fix_text.strip()

        # 更新主界面摘要
        self._update_main_summary(diagnosis)

    def _update_main_summary(self, diagnosis: dict):
        """更新主界面的上次检测摘要"""
        screen = [s for s in self.root.screens if s.name == "main"]
        if not screen:
            return
        main = screen[0]

        health = diagnosis.get("overall_health", "未知")
        score = diagnosis.get("overall_score", 0)
        ns = diagnosis.get("network_summary", {})

        summary_text = (
            f"健康度: {health} ({score}/100)\n"
            f"延迟: {ns.get('avg_latency_ms', 0):.0f}ms | "
            f"下载: {ns.get('download_mbps', 0):.1f}Mbps"
        )
        main.ids.get("summary_text", object()).text = summary_text

        ts = diagnosis.get("timestamp", "")
        main.ids.get("summary_time", object()).text = f"检测时间: {ts}"

    def _show_error(self, message: str):
        """显示错误提示"""
        screen = [s for s in self.root.screens if s.name == "test"]
        if screen:
            test_screen = screen[0]
            lbl = test_screen.ids.get("progress_detail")
            if lbl:
                lbl.text = f"❌ {message}"
                lbl.color = (0.9, 0.2, 0.2, 1)

        # 2 秒后回到主界面
        Clock.schedule_once(lambda dt: self.go_home(), 2.0)

    # ============================================================
    # 报告操作
    # ============================================================
    def open_report(self):
        """在浏览器中打开完整报告"""
        if self.report_path and os.path.exists(self.report_path):
            try:
                webbrowser.open(f"file://{os.path.abspath(self.report_path)}")
            except Exception as e:
                print(f"[App] 打开报告失败: {e}")

    def share_report(self):
        """分享报告（移动端调用系统分享）"""
        if self.report_path and os.path.exists(self.report_path):
            # 在移动端可以调用系统分享 intent
            print(f"[App] 报告路径: {self.report_path}")
            # Android: 使用 plyer 或 pyjnius
            try:
                from plyer import share
                share.share(
                    title="网络诊断报告",
                    text=f"网络诊断报告已生成: {self.report_path}",
                )
            except ImportError:
                # 回退: 打开文件位置
                self.open_report()

    # ============================================================
    # 生命周期
    # ============================================================
    def on_start(self):
        """应用启动时"""
        print("[App] 网络诊断工具已启动")
        print(f"[App] KivyMD: {'已加载' if use_kivymd else '未安装 (使用纯 Kivy)'}")
        print(f"[App] 工作目录: {os.getcwd()}")

    def on_stop(self):
        """应用关闭时"""
        print("[App] 网络诊断工具已关闭")
        if self.is_testing:
            self.orchestrator.stop()


# ============================================================
# 程序入口
# ============================================================
if __name__ == "__main__":
    print("=" * 50)
    print("网络卡顿自查检测工具 v1.0")
    print("=" * 50)
    print()

    # 检查依赖
    try:
        import kivy
        print(f"✅ Kivy: {kivy.__version__}")
    except ImportError:
        print("❌ Kivy 未安装，请运行: pip install kivy")
        sys.exit(1)

    try:
        import kivymd
        print(f"✅ KivyMD: {kivymd.__version__}")
    except ImportError:
        print("⚠ KivyMD 未安装 (可选)，使用纯 Kivy 模式")

    print()

    # 启动应用
    NetworkDiagApp().run()
