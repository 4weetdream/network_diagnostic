# ============================================================
# Buildozer 配置文件 - 打包 Android APK
# ============================================================
# 使用方式:
#   方法1 (Docker): docker run -v $(pwd):/app -v ~/.buildozer:/home/user/.buildozer kivy/buildozer -v android debug
#   方法2 (Linux):  buildozer android debug

[app]

# 应用名称 (显示在手机桌面)
title = 网络诊断

# 包名 (唯一标识)
package.name = networkdiagnostic

# 域名 (反向包名)
package.domain = org.example.networkdiag

# 源码目录
source.dir = .

# 需要额外包含的文件/目录
source.include_exts = py,png,jpg,kv,atlas,ttf

# 版本号 (静态版本)
version = 1.0.0

# 编译需求 (Python 包 - 标准库模块无需在此列出)
requirements = python3,kivy==2.2.1,kivymd==1.1.1

# 编译架构 (arm64-v8a 兼容大多数新手机)
android.archs = arm64-v8a,armeabi-v7a

# Android API 等级
android.api = 31
android.minapi = 21

# 权限声明
android.permissions = \
    INTERNET, \
    ACCESS_WIFI_STATE, \
    ACCESS_NETWORK_STATE, \
    CHANGE_WIFI_STATE, \
    ACCESS_FINE_LOCATION, \
    ACCESS_COARSE_LOCATION, \
    READ_EXTERNAL_STORAGE, \
    WRITE_EXTERNAL_STORAGE

# 允许应用在后台运行
android.add_activity_to_manifest = True
android.wakelock = True

# 启动图标
# icon = icon.png
# icon 可以是 512x512 PNG 或 192x192 PNG

# 启动画面
# presplash = splash.png

# 元数据 (使用英文避免编码问题)
# package.metadata = description=Network diagnostic tool,author=NetworkDiagnostic

# 签名 (调试模式自动使用 debug 证书)
# android.keyalias = myapp
# android.keystore = myapp.ketytore
# android.keystore_password =
# android.keyalias_password =

# 是否全屏 (0=否, 1=是)
android.fullscreen = 0

# 是否启用广告 ID
android.enable_ads = False

# logcat 过滤
android.logcat_filters = *:S python:V kivy:V

# p4a 使用本地源码 (已预克隆)
p4a.source_dir = ./.buildozer/android/platform/python-for-android
# 云端构建用 branch: p4a.branch = develop

# ============================================================
# 编译选项
# ============================================================

[buildozer]

# 日志级别
log_level = 2

# 编译输出目录
bin.dir = ./bin

# ============================================================
# Android 平台特定选项
# ============================================================

[android]

# 调试模式自动重装
android.gradle_dependencies = 'androidx.core:core:1.9.0'
# android.gradle_api_version = 31
# android.gradle_build_tools_version = 8.0.0

# 需要解压的 so 库
# android.add_src = java/

# ============================================================
# iOS 平台 (暂不需要)
# ============================================================

[ios]
codesign.allowed = false
