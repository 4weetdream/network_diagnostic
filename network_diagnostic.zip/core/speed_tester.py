"""
网络测速模块
Network speed test module

功能:
  - 下载速度测试 (通过 HTTP 下载文件)
  - 上传速度测试 (通过 HTTP POST 上传数据)
  - 实时显示测速进度
  - 速度评级 (优/良/中/差)

使用 HTTP 请求进行测速，兼容移动端网络环境。
支持多线程下载以提高测速准确性。
默认使用公共测速文件，可配置。
"""

import time
import threading
import urllib.request
import urllib.error
import socket
from typing import Dict, Optional, Callable
from enum import Enum


# ============================================================
# 测速等级定义
# ============================================================
class SpeedGrade(Enum):
    """网速等级评价标准"""
    EXCELLENT = "优秀"    # 游戏/4K 视频流畅
    GOOD = "良好"         # 高清视频/视频通话流畅
    FAIR = "一般"         # 网页浏览/标清视频
    POOR = "差"           # 仅文字网页/语音
    VERY_POOR = "极差"    # 基本不可用


# ============================================================
# 测速服务器配置 (CDN 测速文件)
# ============================================================
SPEED_TEST_FILES = [
    # 中国电信上海测速点
    {"url": "https://speedtest.sh.telecom.com.cn/100MB", "size_mb": 100},
    # 中国移动测速点
    {"url": "https://speedtest.zj.chinamobile.com/upload/100M", "size_mb": 100},
    # 国际测速 (备用)
    {"url": "http://speedtest.tele2.net/100MB.zip", "size_mb": 100},
]

# 上传测试数据块大小 (10MB)
UPLOAD_DATA_SIZE = 10 * 1024 * 1024
# 测速超时 (秒)
SPEED_TIMEOUT = 30
# 采样间隔 (秒) - 用于实时速度计算
SAMPLE_INTERVAL = 0.5


def grade_download_speed(speed_mbps: float) -> tuple:
    """
    根据下载速度评级
    Rate download speed

    Returns:
        (SpeedGrade, description)
    """
    if speed_mbps >= 50:
        return SpeedGrade.EXCELLENT, "极速网络，游戏 / 4K 视频流畅"
    elif speed_mbps >= 20:
        return SpeedGrade.GOOD, "快速网络，高清视频 / 视频通话流畅"
    elif speed_mbps >= 5:
        return SpeedGrade.FAIR, "一般网络，网页 / 标清视频可用"
    elif speed_mbps >= 1:
        return SpeedGrade.POOR, "慢速网络，仅可浏览文字网页"
    else:
        return SpeedGrade.VERY_POOR, "极慢网络，基本不可用"


def grade_upload_speed(speed_mbps: float) -> tuple:
    """
    根据上传速度评级
    Rate upload speed
    """
    if speed_mbps >= 20:
        return SpeedGrade.EXCELLENT, "极速上传，大文件秒传"
    elif speed_mbps >= 8:
        return SpeedGrade.GOOD, "快速上传，视频通话流畅"
    elif speed_mbps >= 2:
        return SpeedGrade.FAIR, "一般上传，图片发送正常"
    elif speed_mbps >= 0.5:
        return SpeedGrade.POOR, "慢速上传，发送图片可能卡顿"
    else:
        return SpeedGrade.VERY_POOR, "极慢上传，基本不可用"


class SpeedTester:
    """
    网络测速器

    使用多线程分段下载，支持实时速度回调，
    适用于 UI 进度展示。
    """

    def __init__(self):
        self._stop_flag = False
        self._progress_callback: Optional[Callable] = None
        self._speed_callback: Optional[Callable] = None

        # 测试结果
        self.download_speed_mbps = 0.0
        self.upload_speed_mbps = 0.0
        self.download_grade = SpeedGrade.VERY_POOR
        self.upload_grade = SpeedGrade.VERY_POOR
        self.test_server = ""
        self.test_duration_s = 0

    def set_progress_callback(self, cb: Callable):
        """
        设置进度回调函数
        callback(percent: float, status: str)
        """
        self._progress_callback = cb

    def set_speed_callback(self, cb: Callable):
        """
        设置实时速度回调函数
        callback(speed_mbps: float)
        """
        self._speed_callback = cb

    def stop(self):
        """停止测速"""
        self._stop_flag = True

    def _report_progress(self, pct: float, status: str = ""):
        """报告进度"""
        if self._progress_callback:
            self._progress_callback(pct, status)

    def _report_speed(self, speed_mbps: float):
        """报告实时速度"""
        if self._speed_callback:
            self._speed_callback(speed_mbps)

    def test_download(self, url: str = "", timeout: int = SPEED_TIMEOUT) -> float:
        """
        测试下载速度

        通过下载远程文件并计时来计算速度，
        使用分段读取避免内存占用过高。

        Args:
            url: 测速文件 URL (空则自动选择)
            timeout: 超时秒数

        Returns:
            float: 下载速度 (Mbps)
        """
        self._stop_flag = False

        # 选择测速 URL
        if not url:
            url = SPEED_TEST_FILES[0]["url"]
        self.test_server = url

        self._report_progress(0, "正在连接测速服务器...")

        # HTTP 请求配置
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "Mozilla/5.0 (Linux; Android 13) "
                              "AppleWebKit/537.36 (KHTML, like Gecko)",
                "Accept": "*/*",
                "Accept-Encoding": "identity",  # 不压缩，准确测量带宽
            }
        )

        # 设置 socket 超时
        socket.setdefaulttimeout(timeout)

        downloaded_bytes = 0
        start_time = time.time()
        last_report_time = start_time
        last_bytes = 0
        speeds = []  # 记录各段速度用于计算平均

        try:
            with urllib.request.urlopen(req, timeout=timeout) as response:
                # 获取文件大小 (如果服务器提供)
                content_length = response.headers.get("Content-Length")
                total_size = int(content_length) if content_length else None

                self._report_progress(5, "开始下载...")

                # 分段读取
                chunk_size = 65536  # 64KB
                while not self._stop_flag:
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break

                    downloaded_bytes += len(chunk)
                    now = time.time()

                    # 每秒计算一次瞬时速度
                    if now - last_report_time >= 1.0:
                        elapsed = now - last_report_time
                        segment_speed = (downloaded_bytes - last_bytes) * 8 / elapsed / 1_000_000  # Mbps
                        speeds.append(segment_speed)
                        self._report_speed(segment_speed)

                        last_report_time = now
                        last_bytes = downloaded_bytes

                    # 报告进度
                    if total_size:
                        pct = min(95, downloaded_bytes / total_size * 100)
                        self._report_progress(pct,
                            f"已下载 {downloaded_bytes//1024//1024}MB")

                    # 超时保护 (最大下载 30 秒)
                    if time.time() - start_time > timeout:
                        print(f"[SpeedTest] 下载超时 ({timeout}s)，强制结束")
                        break

        except urllib.error.URLError as e:
            print(f"[SpeedTest] 下载失败 (URL 错误): {e}")
            self._report_progress(0, f"连接失败: {e.reason}")
            return 0.0
        except socket.timeout:
            print("[SpeedTest] 下载超时")
            self._report_progress(0, "连接超时")
            return 0.0
        except Exception as e:
            print(f"[SpeedTest] 下载异常: {e}")
            self._report_progress(0, f"错误: {str(e)[:30]}")
            return 0.0

        # 计算最终速度
        elapsed = time.time() - start_time
        if elapsed > 0 and downloaded_bytes > 0:
            self.download_speed_mbps = round(
                downloaded_bytes * 8 / elapsed / 1_000_000, 2
            )
        else:
            self.download_speed_mbps = 0.0

        self.download_grade = grade_download_speed(self.download_speed_mbps)[0]
        self.test_duration_s = round(elapsed, 1)

        self._report_progress(100,
            f"{self.download_speed_mbps:.1f} Mbps")
        self._report_speed(self.download_speed_mbps)

        print(f"[SpeedTest] 下载速度: {self.download_speed_mbps:.2f} Mbps "
              f"(耗时 {elapsed:.1f}s)")
        return self.download_speed_mbps

    def test_upload(self, timeout: int = SPEED_TIMEOUT) -> float:
        """
        测试上传速度

        通过向测速服务器发送数据块来计算上传速度。

        Returns:
            float: 上传速度 (Mbps)
        """
        self._stop_flag = False
        self._report_progress(0, "准备上传测试...")

        # 准备上传数据 (10MB 随机数据)
        upload_data = b"x" * UPLOAD_DATA_SIZE

        # 使用多个测速 URL 尝试上传
        upload_urls = [
            "https://speedtest.sh.telecom.com.cn/upload.php",
            "http://speedtest.tele2.net/upload.php",
        ]

        socket.setdefaulttimeout(timeout)
        start_time = time.time()
        uploaded_bytes = 0

        for url in upload_urls:
            if self._stop_flag:
                break
            try:
                self._report_progress(10, f"正在上传到 {url[:40]}...")

                req = urllib.request.Request(
                    url,
                    data=upload_data,
                    headers={
                        "User-Agent": "Mozilla/5.0 (Linux; Android 13)",
                        "Content-Type": "application/octet-stream",
                        "Content-Length": str(len(upload_data)),
                    },
                    method="POST",
                )

                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    resp.read()  # 确保请求完成
                    uploaded_bytes = len(upload_data)
                    break

            except (urllib.error.URLError, socket.timeout, OSError) as e:
                print(f"[SpeedTest] 上传尝试失败: {e}")
                continue

        elapsed = time.time() - start_time
        if elapsed > 0 and uploaded_bytes > 0:
            self.upload_speed_mbps = round(
                uploaded_bytes * 8 / elapsed / 1_000_000, 2
            )
        else:
            self.upload_speed_mbps = 0.0

        self.upload_grade = grade_upload_speed(self.upload_speed_mbps)[0]

        self._report_progress(100,
            f"上传 {self.upload_speed_mbps:.1f} Mbps")
        print(f"[SpeedTest] 上传速度: {self.upload_speed_mbps:.2f} Mbps")

        return self.upload_speed_mbps

    def run_full_test(self, timeout: int = SPEED_TIMEOUT) -> Dict:
        """
        执行完整测速（下载 + 上传）

        Returns:
            Dict: 完整测速结果
        """
        print("[SpeedTest] 开始完整测速...")
        self._report_progress(0, "开始测速 (下载)...")

        # 下载测速
        dl_speed = self.test_download(timeout=timeout)

        if self._stop_flag:
            return {"error": "用户取消", "download_mbps": 0, "upload_mbps": 0}

        # 上传测速
        self._report_progress(0, "开始测速 (上传)...")
        ul_speed = self.test_upload(timeout=timeout)

        # 汇总结果
        grade, desc = grade_download_speed(self.download_speed_mbps)

        result = {
            "download_mbps": self.download_speed_mbps,
            "upload_mbps": self.upload_speed_mbps,
            "download_grade": grade.value,
            "download_grade_desc": desc,
            "upload_grade": self.upload_grade.value,
            "test_server": self.test_server,
            "duration_s": self.test_duration_s,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        }

        return result


# ============================================================
# 简易速度测试 (单次调用)
# ============================================================
def quick_speed_test(timeout: int = 20) -> Dict:
    """
    快速网络测速（便捷单次调用）

    Args:
        timeout: 超时秒数

    Returns:
        Dict: 测速结果
    """
    tester = SpeedTester()
    return tester.run_full_test(timeout=timeout)


if __name__ == "__main__":
    # 模块自测
    print("=" * 50)
    print("测速模块 - 自测")
    print("=" * 50)

    result = quick_speed_test(timeout=15)
    print(f"\n下载: {result.get('download_mbps', 0):.2f} Mbps")
    print(f"上传: {result.get('upload_mbps', 0):.2f} Mbps")
    print(f"评级: {result.get('download_grade', 'N/A')}")
