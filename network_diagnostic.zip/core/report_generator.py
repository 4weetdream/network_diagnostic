"""
图文报告生成模块
Graphical report generator

功能:
  - 生成 HTML 格式图文报告
  - 网络状态可视化（评分表、柱状图、信号强度指示）
  - 问题诊断详情与建议
  - 适配手机屏幕显示
  - 支持导出分享

依赖:
  - 使用纯 HTML + CSS + 内嵌 SVG 图表
  - 无需外部绘图库
  - 手机浏览器即可打开
"""

import time
import os
import webbrowser
from typing import Dict, List, Optional
from datetime import datetime


# ============================================================
# CSS 样式 (移动端适配)
# ============================================================
REPORT_CSS = """
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: -apple-system, 'PingFang SC', 'Microsoft YaHei', sans-serif;
    background: #f5f7fa;
    color: #333;
    font-size: 14px;
    line-height: 1.6;
    padding: 0;
    max-width: 100%;
  }

  /* 顶部横幅 */
  .header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 28px 20px 20px;
    text-align: center;
    border-radius: 0 0 24px 24px;
  }
  .header h1 { font-size: 22px; font-weight: 700; margin-bottom: 4px; }
  .header .time { font-size: 12px; opacity: 0.8; }

  /* 评分大圆环 */
  .score-ring {
    width: 120px; height: 120px;
    margin: -60px auto 16px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center; justify-content: center;
    flex-direction: column;
    box-shadow: 0 4px 20px rgba(0,0,0,0.12);
    position: relative;
    z-index: 10;
  }
  .score-ring .score-value {
    font-size: 36px; font-weight: 800;
    background: linear-gradient(135deg, #667eea, #764ba2);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    line-height: 1;
  }
  .score-ring .score-label {
    font-size: 12px; color: #888;
    margin-top: 2px;
  }
  .score-ring {
    background: conic-gradient(
      #667eea var(--score-deg, 0deg),
      #e8e8e8 var(--score-deg, 0deg)
    );
    padding: 6px;
  }
  .score-ring-inner {
    background: white;
    border-radius: 50%;
    width: 100%; height: 100%;
    display: flex; align-items: center; justify-content: center;
    flex-direction: column;
  }

  /* 健康度标签 */
  .health-badge {
    display: inline-block;
    padding: 4px 16px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
    margin: 8px 0 4px;
  }
  .health-excellent { background: #d4edda; color: #155724; }
  .health-good { background: #cce5ff; color: #004085; }
  .health-fair { background: #fff3cd; color: #856404; }
  .health-poor { background: #f8d7da; color: #721c24; }
  .health-bad { background: #f5c6cb; color: #491217; }

  /* 卡片容器 */
  .card {
    background: white;
    border-radius: 14px;
    margin: 12px 16px;
    padding: 16px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
  }
  .card h2 {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 12px;
    padding-bottom: 8px;
    border-bottom: 2px solid #f0f0f0;
    display: flex;
    align-items: center;
    gap: 6px;
  }

  /* 指标网格 */
  .metrics {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
  }
  .metric-item {
    background: #f8f9fe;
    border-radius: 10px;
    padding: 12px;
    text-align: center;
  }
  .metric-item .value {
    font-size: 22px;
    font-weight: 700;
    color: #667eea;
  }
  .metric-item .label {
    font-size: 11px;
    color: #999;
    margin-top: 2px;
  }
  .metric-item .status-dot {
    display: inline-block;
    width: 8px; height: 8px;
    border-radius: 50%;
    margin-right: 4px;
  }
  .dot-green { background: #28a745; }
  .dot-yellow { background: #ffc107; }
  .dot-red { background: #dc3545; }

  /* 信号强度条 */
  .signal-bar-container { margin: 8px 0; }
  .signal-bar {
    height: 8px;
    background: #e8e8e8;
    border-radius: 4px;
    overflow: hidden;
    margin-top: 4px;
  }
  .signal-bar-fill {
    height: 100%;
    border-radius: 4px;
    transition: width 0.5s;
  }

  /* 问题列表 */
  .problem-item {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 10px 0;
    border-bottom: 1px solid #f0f0f0;
  }
  .problem-item:last-child { border-bottom: none; }
  .problem-icon { font-size: 20px; flex-shrink: 0; }
  .problem-content { flex: 1; }
  .problem-title {
    font-weight: 600;
    font-size: 14px;
  }
  .problem-detail {
    font-size: 12px;
    color: #666;
    margin-top: 2px;
  }
  .problem-confidence {
    display: inline-block;
    font-size: 11px;
    color: #999;
    margin-top: 4px;
  }

  /* 建议列表 */
  .suggestion-item {
    background: #f0f7ff;
    border-radius: 10px;
    padding: 12px;
    margin-bottom: 10px;
    border-left: 3px solid #667eea;
  }
  .suggestion-item .action {
    font-weight: 600;
    font-size: 14px;
    color: #333;
  }
  .suggestion-item .effect {
    font-size: 12px;
    color: #28a745;
    margin-top: 4px;
  }
  .suggestion-item ol {
    margin: 6px 0 0 16px;
    font-size: 12px;
    color: #555;
  }
  .suggestion-item ol li { margin-bottom: 3px; }

  /* 带宽应用列表 */
  .app-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 6px 0;
    border-bottom: 1px solid #f5f5f5;
    font-size: 13px;
  }
  .app-item:last-child { border-bottom: none; }
  .app-category {
    display: inline-block;
    font-size: 10px;
    padding: 2px 6px;
    border-radius: 8px;
    background: #e8e8e8;
    color: #666;
    margin-left: 6px;
  }
  .app-score {
    font-weight: 600;
    color: #dc3545;
  }
  .bw-bar {
    width: 60px; height: 4px;
    background: #e8e8e8;
    border-radius: 2px;
    overflow: hidden;
    display: inline-block;
    vertical-align: middle;
    margin-left: 8px;
  }
  .bw-bar-fill {
    height: 100%;
    background: #dc3545;
    border-radius: 2px;
  }

  /* 底部元数据 */
  .footer {
    text-align: center;
    padding: 20px;
    font-size: 11px;
    color: #aaa;
  }

  /* 响应式 */
  @media (max-width: 480px) {
    .metrics { grid-template-columns: 1fr 1fr; }
    .card { margin: 8px 12px; padding: 14px; }
  }
</style>
"""


# ============================================================
# 报告生成函数
# ============================================================
def _get_health_class(health: str) -> str:
    """获取健康度对应的 CSS 类名"""
    mapping = {
        "优秀": "health-excellent", "良好": "health-good",
        "一般": "health-fair", "较差": "health-poor",
        "极差": "health-bad",
    }
    return mapping.get(health, "health-fair")


def _score_to_deg(score: int) -> int:
    """评分转环形图角度"""
    return int(score * 360 / 100)


def _render_header(diagnosis: Dict) -> str:
    """渲染报告头部"""
    health = diagnosis.get("overall_health", "未知")
    score = diagnosis.get("overall_score", 0)
    health_desc = diagnosis.get("overall_health_desc", "")
    ts = diagnosis.get("timestamp", time.strftime("%Y-%m-%d %H:%M:%S"))

    return f"""
    <div class="header">
      <h1>📊 网络诊断报告</h1>
      <div class="time">检测时间: {ts}</div>
    </div>
    <div class="score-ring" style="--score-deg: {_score_to_deg(score)}deg">
      <div class="score-ring-inner">
        <div class="score-value">{score}</div>
        <div class="score-label">综合评分</div>
      </div>
    </div>
    <div style="text-align:center; margin: -8px 0 8px;">
      <span class="health-badge {_get_health_class(health)}">{health}</span>
      <div style="font-size:12px; color:#888; margin-top:4px;">{health_desc}</div>
    </div>
    """


def _render_network_summary(diagnosis: Dict) -> str:
    """渲染网络信息摘要卡片"""
    ns = diagnosis.get("network_summary", {})
    net_type = ns.get("network_type", "未知")
    ssid = ns.get("wifi_ssid", "")
    latency = ns.get("avg_latency_ms", 0)
    dl = ns.get("download_mbps", 0)
    ul = ns.get("upload_mbps", 0)

    latency_color = "green" if latency < 30 else ("yellow" if latency < 80 else "red")
    dl_color = "green" if dl > 30 else ("yellow" if dl > 8 else "red")
    ul_color = "green" if ul > 8 else ("yellow" if ul > 2 else "red")

    return f"""
    <div class="card">
      <h2>🌐 网络概况</h2>
      <div style="font-size:13px; margin-bottom:10px;">
        <span style="color:#666;">连接:</span>
        <strong>{'WiFi' if 'wifi' in net_type else net_type}</strong>
        {f'({ssid})' if ssid else ''}
      </div>
      <div class="metrics">
        <div class="metric-item">
          <div class="value">
            <span class="status-dot dot-{latency_color}"></span>
            {latency:.0f}
          </div>
          <div class="label">延迟 (ms)</div>
        </div>
        <div class="metric-item">
          <div class="value">
            <span class="status-dot dot-{dl_color}"></span>
            {dl:.1f}
          </div>
          <div class="label">下载 (Mbps)</div>
        </div>
        <div class="metric-item">
          <div class="value">
            <span class="status-dot dot-{ul_color}"></span>
            {ul:.2f}
          </div>
          <div class="label">上传 (Mbps)</div>
        </div>
        <div class="metric-item">
          <div class="value">{ns.get('signal_pct', 'N/A')}%</div>
          <div class="label">信号强度</div>
        </div>
      </div>
    </div>
    """


def _render_ping_details(diagnosis: Dict) -> str:
    """渲染 Ping 检测详情"""
    problems = diagnosis.get("problems", [])

    # 从诊断结果中提取 Ping 详情
    latency_problems = [p for p in problems if p["dimension"] == "high_latency"]
    loss_problems = [p for p in problems if p["dimension"] == "packet_loss"]
    jitter_problems = [p for p in problems if p["dimension"] == "carrier_fluctuation"]
    dns_problems = [p for p in problems if p["dimension"] == "dns_pollution"]

    parts = []
    for title, plist in [
        ("延迟", latency_problems), ("丢包", loss_problems),
        ("抖动", jitter_problems), ("DNS", dns_problems),
    ]:
        for p in plist:
            conf = p.get("confidence", 0) * 100
            parts.append(f"""
              <div class="problem-item">
                <div class="problem-icon">⚠</div>
                <div class="problem-content">
                  <div class="problem-title">{title}异常</div>
                  <div class="problem-detail">{p.get('detail', '')}</div>
                  <div class="problem-confidence">置信度: {conf:.0f}%</div>
                </div>
              </div>
            """)

    if not parts:
        parts.append("""
          <div style="text-align:center; padding:16px; color:#28a745;">
            ✅ 延迟与连接正常
          </div>
        """)

    return f"""
    <div class="card">
      <h2>📡 延迟与连接</h2>
      {''.join(parts)}
    </div>
    """


def _render_signal_details(diagnosis: Dict) -> str:
    """渲染信号检测详情"""
    problems = diagnosis.get("problems", [])
    signal_problems = [p for p in problems
                       if p["dimension"] in ("weak_signal", "wifi_congestion")]
    ns = diagnosis.get("network_summary", {})
    signal_pct = ns.get("signal_pct", 0)

    # 信号强度条
    signal_color = "#28a745" if signal_pct >= 70 else (
        "#ffc107" if signal_pct >= 40 else "#dc3545")

    parts = f"""
    <div style="margin-bottom:10px;">
      <div style="display:flex; justify-content:space-between; font-size:13px;">
        <span>📶 信号强度</span>
        <strong>{signal_pct}%</strong>
      </div>
      <div class="signal-bar">
        <div class="signal-bar-fill" style="width:{signal_pct}%;background:{signal_color};"></div>
      </div>
    </div>
    """

    # 信号问题
    for p in signal_problems:
        conf = p.get("confidence", 0) * 100
        parts += f"""
        <div class="problem-item">
          <div class="problem-content">
            <div class="problem-title">{'📡' if 'signal' in p['dimension'] else '📶'} {p.get('detail', '')}</div>
            <div class="problem-confidence">置信度: {conf:.0f}%</div>
          </div>
        </div>
        """

    if not signal_problems and signal_pct > 0:
        parts += """
        <div style="text-align:center; padding:8px; color:#28a745; font-size:13px;">
          ✅ 信号状态良好
        </div>
        """

    return f"""
    <div class="card">
      <h2>📶 信号检测</h2>
      {parts}
    </div>
    """


def _render_bandwidth_details(diagnosis: Dict) -> str:
    """渲染带宽检测详情"""
    problems = diagnosis.get("problems", [])
    bw_problems = [p for p in problems if p["dimension"] == "bandwidth_preemption"]

    parts = ""
    for p in bw_problems:
        conf = p.get("confidence", 0) * 100
        detail = p.get("detail", "")
        parts += f"""
        <div class="problem-item">
          <div class="problem-icon">⚡</div>
          <div class="problem-content">
            <div class="problem-title">带宽抢占</div>
            <div class="problem-detail">{detail}</div>
            <div class="problem-confidence">置信度: {conf:.0f}%</div>
          </div>
        </div>
        """

    if not parts:
        parts = """
        <div style="text-align:center; padding:16px; color:#28a745;">
          ✅ 带宽占用正常
        </div>
        """

    # 假设的带宽占用列表 (实际数据由 bandwidth_scanner 提供)
    # 这里从 diagnosis 的原始问题详情中提取
    parts += """
    <div style="margin-top:10px; font-size:12px; color:#888;">
      💡 提示: 可在系统任务管理器/应用管理中查看各 App 实时流量
    </div>
    """

    return f"""
    <div class="card">
      <h2>⚡ 带宽占用</h2>
      {parts}
    </div>
    """


def _render_fix_suggestions(diagnosis: Dict) -> str:
    """渲染修复建议"""
    suggestions = diagnosis.get("fix_suggestions", [])

    if not suggestions:
        return f"""
        <div class="card">
          <h2>🔧 修复建议</h2>
          <div style="text-align:center; padding:16px; color:#28a745;">
            ✅ 未检测到需要修复的问题
          </div>
        </div>
        """

    parts = ""
    for s in suggestions[:6]:  # 最多显示 6 条
        steps_html = "".join(
            f"<li>{step}</li>" for step in s.get("steps", [])
        )
        parts += f"""
        <div class="suggestion-item">
          <div class="action">🔧 {s.get('action', '')}</div>
          <div class="effect">✨ {s.get('expected_effect', '')}</div>
          <ol>{steps_html}</ol>
        </div>
        """

    return f"""
    <div class="card">
      <h2>🔧 一键解决建议</h2>
      {parts}
    </div>
    """


def _render_disclaimer() -> str:
    """渲染免责声明"""
    return f"""
    <div class="card" style="background:#fff8e1;">
      <h2>📌 说明</h2>
      <div style="font-size:12px; color:#856404; line-height:1.8;">
        1. 本报告由手机端网络诊断工具自动生成<br>
        2. 信号和带宽检测受系统权限限制，部分数据可能不精确<br>
        3. 网络环境是动态变化的，建议在不同时段多次测试<br>
        4. 修复建议仅供参考，操作前请确保理解每一步的影响
      </div>
    </div>
    """


def generate_html_report(diagnosis: Dict) -> str:
    """
    生成完整的 HTML 诊断报告

    Args:
        diagnosis: diagnose() 函数的输出结果

    Returns:
        str: 完整的 HTML 文档字符串
    """
    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>网络诊断报告</title>
  {REPORT_CSS}
</head>
<body>
  {_render_header(diagnosis)}
  {_render_network_summary(diagnosis)}
  {_render_ping_details(diagnosis)}
  {_render_signal_details(diagnosis)}
  {_render_bandwidth_details(diagnosis)}
  {_render_fix_suggestions(diagnosis)}
  {_render_disclaimer()}
  <div class="footer">
    由 NetworkDiagnostic 工具生成 · 仅供自查参考
  </div>
</body>
</html>"""

    return html


def save_report(diagnosis: Dict, filepath: str = "") -> str:
    """
    保存诊断报告到文件

    Args:
        diagnosis: 诊断结果字典
        filepath: 保存路径（默认为当前目录）

    Returns:
        str: 保存的文件路径
    """
    html = generate_html_report(diagnosis)

    if not filepath:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = f"network_report_{ts}.html"

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"[Report] 报告已保存: {os.path.abspath(filepath)}")
    return os.path.abspath(filepath)


def open_report(filepath: str):
    """在浏览器中打开报告"""
    try:
        webbrowser.open(f"file://{filepath}")
        print(f"[Report] 已在浏览器中打开报告")
    except Exception as e:
        print(f"[Report] 打开报告失败: {e}")


if __name__ == "__main__":
    print("报告生成模块 - 自测")

    # 模拟诊断数据
    mock_diagnosis = {
        "overall_health": "一般",
        "overall_health_desc": "网络存在明显问题，建议排查",
        "overall_score": 62,
        "problems": [
            {"dimension": "high_latency", "confidence": 0.75,
             "detail": "平均延迟 125ms，属于中延迟网络"},
            {"dimension": "weak_signal", "confidence": 0.60,
             "detail": "WiFi 信号偏弱 (35%)，可能影响网络稳定性"},
            {"dimension": "bandwidth_preemption", "confidence": 0.55,
             "detail": "后台带宽占用严重\n  可疑应用: xunlei.exe, svchost.exe"},
        ],
        "fix_suggestions": [
            {"priority": 1, "action": "关闭后台高带宽应用",
             "steps": ["检查云盘同步是否运行", "关闭下载工具"],
             "expected_effect": "释放 30-80% 被占用的带宽"},
            {"priority": 2, "action": "靠近路由器",
             "steps": ["尽量在路由器 5 米范围内使用"],
             "expected_effect": "信号强度提升 20-50%"},
        ],
        "network_summary": {
            "network_type": "wifi", "wifi_ssid": "HomeWiFi",
            "avg_latency_ms": 125, "download_mbps": 8.5,
            "upload_mbps": 2.0, "signal_pct": 35, "health": "一般",
        },
        "timestamp": "2025-01-15 14:30:00",
    }

    # 生成报告
    path = save_report(mock_diagnosis)
    print(f"报告文件: {path}")
    # open_report(path)  # 取消注释以在浏览器中查看
