"""
检测编排器 - 统一调度所有检测模块
Test orchestrator - Coordinate all detection modules

功能:
  - 按依赖顺序依次执行各检测模块
  - 提供进度回调（给 UI 使用）
  - 汇总所有检测结果
  - 支持断点续测（部分模块跳过）
"""

import time
import threading
from typing import Dict, Optional, Callable

from . import ping_tester
from . import speed_tester
from . import signal_detector
from . import bandwidth_scanner
from . import diagnosis_engine
from . import report_generator


class TestOrchestrator:
    """
    检测流程编排器

    管理检测全生命周期:
    init → run_all (并行/串行) → diagnose → generate_report
    """

    # 检测流程阶段定义
    PHASES = [
        {"name": "ping", "label": "延迟检测 (Ping)", "weight": 15},
        {"name": "signal", "label": "信号检测", "weight": 10},
        {"name": "speed", "label": "网速测试", "weight": 40},
        {"name": "bandwidth", "label": "带宽扫描", "weight": 20},
        {"name": "diagnose", "label": "综合分析诊断", "weight": 10},
        {"name": "report", "label": "生成报告", "weight": 5},
    ]

    def __init__(self):
        self._progress_callback: Optional[Callable] = None
        self._phase_callback: Optional[Callable] = None
        self._stop_flag = False

        # 存储阶段性结果
        self.results = {
            "ping": None,
            "signal": None,
            "speed": None,
            "bandwidth": None,
        }
        self.diagnosis_result = None
        self.report_path = ""

        # 测速器实例（支持取消）
        self._speed_tester = speed_tester.SpeedTester()

    def set_progress_callback(self, cb: Callable):
        """设置全局进度回调 (percent: float, phase: str, status: str)"""
        self._progress_callback = cb

    def set_phase_callback(self, cb: Callable):
        """设置阶段变更回调 (phase_name: str)"""
        self._phase_callback = cb

    def _report_progress(self, pct: float, phase: str = "", status: str = ""):
        """报告进度"""
        if self._progress_callback:
            self._progress_callback(pct, phase, status)
        if phase and self._phase_callback:
            self._phase_callback(phase)

    def stop(self):
        """停止所有检测"""
        self._stop_flag = True
        self._speed_tester.stop()
        print("[Orchestrator] 用户取消检测")

    def _calc_overall_progress(self, phase_idx: int, phase_pct: float = 0) -> float:
        """计算整体进度百分比"""
        total_weight = sum(p["weight"] for p in self.PHASES)
        done_weight = sum(self.PHASES[i]["weight"] for i in range(phase_idx))
        current_weight = self.PHASES[phase_idx]["weight"]
        return (done_weight + current_weight * phase_pct / 100) / total_weight * 100

    def run_phase_ping(self) -> Dict:
        """阶段1: 延迟检测"""
        self._report_progress(0, "ping", "正在检测默认网关...")
        result = ping_tester.run_all_ping_tests()
        self.results["ping"] = result

        summary = result.get("summary", {})
        pct = self._calc_overall_progress(0)
        self._report_progress(pct, "ping",
            f"延迟: {summary.get('avg_latency_ms', 0):.0f}ms, "
            f"丢包: {summary.get('avg_loss_rate', 0):.0f}%")
        return result

    def run_phase_signal(self) -> Dict:
        """阶段2: 信号检测"""
        self._report_progress(0, "signal", "正在扫描信号强度...")
        result = signal_detector.run_all_signal_tests()
        self.results["signal"] = result

        wifi = result.get("wifi", {})
        signal_str = f"信号: {wifi.get('signal_pct', 'N/A')}%"
        if result.get("channel_congestion"):
            signal_str += f", 信道: {result['channel_congestion'].get('level', '')}"

        pct = self._calc_overall_progress(1)
        self._report_progress(pct, "signal", signal_str)
        return result

    def run_phase_speed(self) -> Dict:
        """阶段3: 网速测试"""
        self._report_progress(0, "speed", "正在测速 (下载)...")

        # 测速阶段进度回调
        def speed_progress(pct: float, status: str):
            overall = self._calc_overall_progress(2, pct)
            self._report_progress(overall, "speed", status)

        self._speed_tester.set_progress_callback(speed_progress)

        # 执行测速
        result = self._speed_tester.run_full_test()
        self.results["speed"] = result

        pct = self._calc_overall_progress(2, 100)
        self._report_progress(pct, "speed",
            f"↓{result.get('download_mbps', 0):.1f} ↑{result.get('upload_mbps', 0):.1f} Mbps")
        return result

    def run_phase_bandwidth(self) -> Dict:
        """阶段4: 带宽占用扫描"""
        self._report_progress(0, "bandwidth", "正在扫描网络连接...")
        result = bandwidth_scanner.run_bandwidth_scan()
        self.results["bandwidth"] = result

        grade = result.get("grade", {})
        pct = self._calc_overall_progress(3)
        self._report_progress(pct, "bandwidth",
            f"评分: {grade.get('score', 0)} ({grade.get('grade', '')})")
        return result

    def run_phase_diagnose(self) -> Dict:
        """阶段5: 综合诊断"""
        self._report_progress(0, "diagnose", "正在综合分析...")
        self.diagnosis_result = diagnosis_engine.diagnose(self.results)

        pct = self._calc_overall_progress(4)
        health = self.diagnosis_result.get("overall_health", "")
        score = self.diagnosis_result.get("overall_score", 0)
        self._report_progress(pct, "diagnose",
            f"诊断结果: {health} ({score}/100)")
        return self.diagnosis_result

    def run_phase_report(self, save_path: str = "") -> str:
        """阶段6: 生成报告"""
        self._report_progress(0, "report", "正在生成诊断报告...")
        if self.diagnosis_result:
            self.report_path = report_generator.save_report(
                self.diagnosis_result, save_path
            )
        pct = self._calc_overall_progress(5, 100)
        self._report_progress(pct, "report", "报告已生成")
        return self.report_path

    def run_all(self) -> Dict:
        """
        执行全套检测流程

        Returns:
            Dict: {
                "success": bool,
                "results": {ping, signal, speed, bandwidth},
                "diagnosis": {...},
                "report_path": str,
            }
        """
        self._stop_flag = False
        start_time = time.time()

        print(f"\n{'='*50}")
        print(f"网络诊断工具 - 开始全面检测")
        print(f"{'='*50}\n")

        try:
            # 阶段1: Ping
            self.run_phase_ping()
            if self._stop_flag:
                raise InterruptedError

            # 阶段2: 信号
            self.run_phase_signal()
            if self._stop_flag:
                raise InterruptedError

            # 阶段3: 测速
            self.run_phase_speed()
            if self._stop_flag:
                raise InterruptedError

            # 阶段4: 带宽
            self.run_phase_bandwidth()
            if self._stop_flag:
                raise InterruptedError

            # 阶段5: 诊断
            self.run_phase_diagnose()

            # 阶段6: 报告
            self.run_phase_report()

            elapsed = time.time() - start_time
            print(f"\n{'='*50}")
            print(f"检测完成! 总耗时: {elapsed:.1f}秒")
            print(f"报告路径: {self.report_path}")
            print(f"{'='*50}")

            return {
                "success": True,
                "results": self.results,
                "diagnosis": self.diagnosis_result,
                "report_path": self.report_path,
                "elapsed_s": round(elapsed, 1),
            }

        except InterruptedError:
            print("[Orchestrator] 检测被用户中断")
            return {
                "success": False,
                "results": self.results,
                "diagnosis": None,
                "report_path": "",
                "error": "用户取消",
            }

        except Exception as e:
            print(f"[Orchestrator] 检测异常: {e}")
            import traceback
            traceback.print_exc()
            return {
                "success": False,
                "results": self.results,
                "diagnosis": None,
                "report_path": "",
                "error": str(e),
            }


def run_diagnostic() -> Dict:
    """
    一键运行完整诊断（便捷入口）

    Returns:
        Dict: 完整诊断结果 + 报告路径
    """
    orchestrator = TestOrchestrator()
    return orchestrator.run_all()


if __name__ == "__main__":
    print("编排器模块 - 自测")

    # 回调示例
    def on_progress(pct, phase, status):
        print(f"\r[进度] {pct:.0f}% | {phase}: {status}", end="", flush=True)

    orchestrator = TestOrchestrator()
    orchestrator.set_progress_callback(on_progress)
    result = orchestrator.run_all()
    print(f"\n\n最终结果: {'成功' if result.get('success') else '失败'}")
    if result.get("report_path"):
        print(f"报告: {result['report_path']}")
