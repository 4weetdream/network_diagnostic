"""
智能故障诊断引擎
Intelligent fault diagnosis engine

功能:
  - 综合分析 ping/测速/信号/带宽 多维检测数据
  - 自动判断卡顿根因（DNS 污染、WiFi 拥堵、信号弱、后台抢占、运营商波动）
  - 给出置信度评分
  - 生成一键解决建议（可操作步骤）

诊断规则:
  采用加权评分 + 规则引擎模式，综合多项指标给出结论。
"""

import time
from typing import Dict, List, Optional, Tuple


# ============================================================
# 诊断维度定义
# ============================================================
DIAGNOSIS_DIMENSIONS = {
    "dns_pollution": {
        "name": "DNS 污染 / 解析异常",
        "icon": "🔍",
        "severity": "high",
    },
    "wifi_congestion": {
        "name": "WiFi 信道拥挤",
        "icon": "📶",
        "severity": "medium",
    },
    "weak_signal": {
        "name": "信号强度弱",
        "icon": "📡",
        "severity": "high",
    },
    "bandwidth_preemption": {
        "name": "后台应用抢占带宽",
        "icon": "⚡",
        "severity": "medium",
    },
    "carrier_fluctuation": {
        "name": "网络运营商波动",
        "icon": "🌐",
        "severity": "low",
    },
    "high_latency": {
        "name": "网络延迟过高",
        "icon": "⏱",
        "severity": "high",
    },
    "packet_loss": {
        "name": "数据包丢失",
        "icon": "📭",
        "severity": "high",
    },
}


# ============================================================
# 修复建议库
# ============================================================
FIX_SUGGESTIONS = {
    "dns_pollution": [
        {"action": "切换 DNS", "steps": [
            "打开手机「设置」→「WiFi」→ 点击当前连接的 WiFi",
            "找到「DNS」或「IP 设置」选项",
            "将 DNS 修改为: 114.114.114.114 (首选) / 8.8.8.8 (备选)",
            "保存并重新连接 WiFi",
        ], "expected_effect": "DNS 解析延迟预计降低 50-200ms"},
        {"action": "开启网络加速", "steps": [
            "部分手机内置网络加速/智能 DNS 功能",
            "可在「设置」→「网络」中查找并开启",
        ], "expected_effect": "智能选择最优 DNS 服务器"},
        {"action": "重启路由器", "steps": [
            "拔掉路由器电源等待 30 秒",
            "重新插电启动",
            "等待 2 分钟后重新连接",
        ], "expected_effect": "清除 DNS 缓存"},
    ],
    "wifi_congestion": [
        {"action": "切换 5GHz 频段", "steps": [
            "进入路由器管理后台 (192.168.1.1 或 192.168.0.1)",
            "在 WiFi 设置中开启 5GHz 频段",
            "将手机连接到 5G WiFi (SSID 可能带有 -5G 后缀)",
            "5GHz 信道更干净，干扰少",
        ], "expected_effect": "信道干扰降低 60-80%"},
        {"action": "更换信道", "steps": [
            "进入路由器管理后台 → WiFi 设置",
            "2.4GHz 推荐使用信道 1/6/11 (互不重叠)",
            "5GHz 推荐使用信道 36-48 或 149-165",
            "保存后路由器会自动重启",
        ], "expected_effect": "避开拥挤信道，减少干扰"},
        {"action": "远离干扰源", "steps": [
            "微波炉、蓝牙音箱、无线鼠标等 2.4GHz 设备会造成干扰",
            "尽量让路由器远离这些设备",
            "避免将路由器放在墙角或金属柜中",
        ], "expected_effect": "减少电磁干扰"},
    ],
    "weak_signal": [
        {"action": "靠近路由器", "steps": [
            "尽量在路由器 5-10 米范围内使用",
            "减少隔墙数量 (尤其是承重墙)",
        ], "expected_effect": "信号强度提升 20-50%"},
        {"action": "调整路由器位置", "steps": [
            "将路由器放在房屋中央高处",
            "避免放在桌面下或墙角",
            "天线垂直向上摆放",
        ], "expected_effect": "覆盖范围扩大 30-50%"},
        {"action": "使用 WiFi 信号增强器", "steps": [
            "购买 WiFi 信号放大器/中继器",
            "放置在路由器和常用位置中间",
        ], "expected_effect": "信号覆盖提升"},
        {"action": "切换至蜂窝数据", "steps": [
            "如果 WiFi 信号极弱 (< 20%)",
            "建议暂时切换为 4G/5G 移动数据",
        ], "expected_effect": "网络稳定性立即改善"},
    ],
    "bandwidth_preemption": [
        {"action": "关闭后台高带宽应用", "steps": [
            "检查以下类型应用是否正在后台运行:",
            "  - 云盘同步 (百度网盘、iCloud 等)",
            "  - 视频 App (后台播放/下载)",
            "  - 系统自动更新 (App Store、系统更新)",
            "  - 下载工具 (迅雷、BT 等)",
            "在任务管理器/应用管理中强制停止这些应用",
        ], "expected_effect": "释放 30-80% 被占用的带宽"},
        {"action": "限制后台数据使用 (Android)", "steps": [
            "「设置」→「无线和网络」→「流量管理」",
            "查看各应用的数据使用量",
            "对高消耗应用开启「后台数据限制」",
            "可在「开发者选项」中限制后台进程数",
        ], "expected_effect": "防止应用在后台偷跑流量"},
        {"action": "暂时关闭自动更新", "steps": [
            "手机：「应用商店」→「设置」→ 关闭「自动更新应用」",
            "Windows: 「设置」→「更新和安全」→ 暂停更新 7 天",
        ], "expected_effect": "避免更新占用全部带宽"},
    ],
    "carrier_fluctuation": [
        {"action": "切换接入点 (APN)", "steps": [
            "「设置」→「移动网络」→「接入点名称 (APN)」",
            "点击当前使用的 APN，将 APN 协议改为 IPv4/IPv6",
            "保存并重启移动数据",
        ], "expected_effect": "改善运营商网络连接稳定性"},
        {"action": "开关飞行模式", "steps": [
            "下拉通知栏，打开「飞行模式」",
            "等待 10 秒后关闭",
            "让手机重新搜索并连接基站",
        ], "expected_effect": "强制重新注册到最佳基站"},
        {"action": "联系运营商", "steps": [
            "如问题持续，可能是基站故障或维护",
            "拨打运营商客服 (移动 10086 / 联通 10010 / 电信 10000)",
            "询问是否附近有基站维护或网络故障",
        ], "expected_effect": "获取运营商侧信息"},
    ],
    "high_latency": [
        {"action": "关闭 VPN/代理", "steps": [
            "如果开启了 VPN/代理/网络加速器，请先关闭",
            "这些服务会增加额外的路由跳数和延迟",
        ], "expected_effect": "延迟降低 30-100ms"},
        {"action": "检查网线连接 (宽带)", "steps": [
            "检查光猫到路由器的网线是否松动",
            "重新插拔两端接口",
            "检查光猫指示灯是否正常 (LOS 灯不能亮红灯)",
        ], "expected_effect": "消除物理层连接问题"},
        {"action": "重启光猫和路由器", "steps": [
            "依次关闭光猫和路由器电源",
            "等待 2 分钟后先开启光猫",
            "光猫启动完成后 (指示灯正常) 再开启路由器",
        ], "expected_effect": "清除设备缓存，重新建立连接"},
    ],
    "packet_loss": [
        {"action": "检查 WiFi 干扰", "steps": [
            "减少路由器周围金属物体",
            "将路由器远离微波炉、蓝牙设备",
            "避免 USB 3.0 设备靠近路由器 (会产生 2.4GHz 干扰)",
        ], "expected_effect": "减少数据包碰撞和丢失"},
        {"action": "更换网线", "steps": [
            "如果是有线连接，检查网线是否老旧或损坏",
            "尝试更换一根 Cat5e 或更高规格的网线",
        ], "expected_effect": "消除物理层丢包"},
        {"action": "联系运营商报修", "steps": [
            "如果丢包率持续 > 5%，可能是线路问题",
            "联系宽带运营商安排上门检测",
        ], "expected_effect": "修复线路问题"},
    ],
}


def _rate_ping(ping_data: Dict) -> Tuple[Dict, float]:
    """
    分析 ping 检测数据
    Analyze ping test results

    Returns:
        (diagnosis_result, weight_score): 诊断结果和权重评分
    """
    problems = []
    severity_sum = 0

    gateway = ping_data.get("gateway", {})
    dns_servers = ping_data.get("dns_servers", [])
    summary = ping_data.get("summary", {})

    avg_latency = summary.get("avg_latency_ms", 0)
    max_jitter = summary.get("max_jitter_ms", 0)
    avg_loss = summary.get("avg_loss_rate", 0)
    worst_loss = summary.get("worst_loss_rate", 0)
    targets_ok = summary.get("targets_ok", 0)
    targets_total = summary.get("targets_tested", 0)

    # --- DNS 问题诊断 ---
    if dns_servers and targets_ok > 0:
        dns_ok = [d for d in dns_servers if d.get("success")]
        if dns_ok:
            # DNS 解析耗时异常
            slow_dns = [d for d in dns_ok if d.get("dns_resolve_ms", 0) > 200]
            if slow_dns:
                problems.append({
                    "dimension": "dns_pollution",
                    "confidence": min(0.9, len(slow_dns) * 0.3 + 0.2),
                    "detail": (
                        f"DNS 解析异常: {slow_dns[0]['name']} "
                        f"解析耗时 {slow_dns[0]['dns_resolve_ms']:.0f}ms "
                        "(正常 < 100ms)"
                    ),
                    "evidence": {
                        "resolve_time_ms": slow_dns[0]["dns_resolve_ms"],
                        "threshold_ms": 100,
                    },
                })

            # DNS 响应慢
            slow_ping = [d for d in dns_ok if d["latency_ms"]["avg"] > 100]
            if slow_ping and not slow_dns:
                problems.append({
                    "dimension": "dns_pollution",
                    "confidence": 0.4,
                    "detail": f"DNS 服务器响应偏慢 ({slow_ping[0]['latency_ms']['avg']:.0f}ms)",
                    "evidence": {
                        "latency_ms": slow_ping[0]["latency_ms"]["avg"],
                    },
                })

    # --- 高延迟诊断 ---
    if avg_latency > 100:
        conf = min(0.95, (avg_latency - 50) / 200)
        level = "高" if avg_latency > 200 else "中"
        problems.append({
            "dimension": "high_latency",
            "confidence": conf,
            "detail": f"平均延迟 {avg_latency:.0f}ms，属于{level}延迟网络",
            "evidence": {"avg_latency_ms": avg_latency},
        })

    # --- 丢包诊断 ---
    if worst_loss > 2:
        conf = min(0.95, worst_loss / 20)
        problems.append({
            "dimension": "packet_loss",
            "confidence": conf,
            "detail": f"最高丢包率 {worst_loss:.0f}% (网关 + DNS)",
            "evidence": {"loss_rate_pct": worst_loss},
        })

    # --- 抖动诊断 ---
    # jitter > 30ms 对实时应用有影响
    if max_jitter > 30:
        problems.append({
            "dimension": "carrier_fluctuation",
            "confidence": min(0.7, max_jitter / 80),
            "detail": f"高网络抖动 ({max_jitter:.0f}ms)，"
                      f"游戏/视频通话可能卡顿",
            "evidence": {"jitter_ms": max_jitter},
        })

    return problems, len(problems)


def _rate_signal(signal_data: Dict) -> Tuple[Dict, float]:
    """
    分析信号检测数据
    Analyze signal test results
    """
    problems = []

    wifi = signal_data.get("wifi", {})
    congestion = signal_data.get("channel_congestion", {})
    network_type = signal_data.get("network_type", "")

    # --- WiFi 信号弱诊断 ---
    if wifi.get("connected"):
        signal_pct = wifi.get("signal_pct", 0)
        rssi = wifi.get("rssi_dbm", 0)

        if signal_pct < 30:
            problems.append({
                "dimension": "weak_signal",
                "confidence": min(0.95, (100 - signal_pct) / 60),
                "detail": (f"WiFi 信号极弱 ({signal_pct}%, {rssi}dBm)，"
                          f"建议靠近路由器或调整位置"),
                "evidence": {
                    "signal_pct": signal_pct,
                    "rssi_dbm": rssi,
                },
            })
        elif signal_pct < 55:
            problems.append({
                "dimension": "weak_signal",
                "confidence": 0.4,
                "detail": (f"WiFi 信号偏弱 ({signal_pct}%)，"
                          f"可能影响网络稳定性"),
                "evidence": {"signal_pct": signal_pct},
            })
    else:
        # 非 WiFi 连接提醒
        if "cellular" in network_type:
            cell = signal_data.get("cellular", {})
            if not cell.get("available"):
                problems.append({
                    "dimension": "weak_signal",
                    "confidence": 0.5,
                    "detail": "蜂窝网络信号信息不可用，"
                              "建议到开阔区域检查信号",
                    "evidence": {"note": "蜂窝信号检测被限制"},
                })

    # --- WiFi 信道拥挤诊断 ---
    if congestion:
        level = congestion.get("level", "")
        if level in ("拥挤", "非常拥挤"):
            problems.append({
                "dimension": "wifi_congestion",
                "confidence": (0.8 if level == "非常拥挤" else 0.6),
                "detail": f"WiFi 信道{congestion.get('description', '拥挤')}",
                "evidence": {
                    "congestion_level": level,
                    "score": congestion.get("score", 0),
                },
            })

    return problems, len(problems)


def _rate_bandwidth(bw_data: Dict) -> Tuple[Dict, float]:
    """
    分析带宽占用数据
    Analyze bandwidth usage data
    """
    problems = []
    grade = bw_data.get("grade", {})

    if grade.get("score", 100) < 50:
        problems.append({
            "dimension": "bandwidth_preemption",
            "confidence": min(0.85, (100 - grade["score"]) / 60),
            "detail": f"后台带宽占用{grade.get('description', '严重')}",
            "evidence": {
                "score": grade.get("score", 0),
                "high_bw_apps": grade.get("high_bw_apps", 0),
                "suspicious_apps": grade.get("suspicious_apps", 0),
            },
        })

        # 添加具体应用信息
        suspicious = bw_data.get("suspicious_apps", [])
        if suspicious:
            problems[-1]["detail"] += (
                f"\n  可疑应用: " +
                ", ".join(s["name"] for s in suspicious[:3])
            )

    return problems, len(problems)


def _rate_speed(speed_data: Dict) -> Tuple[Dict, float]:
    """
    分析测速数据
    Analyze speed test results
    """
    problems = []
    dl = speed_data.get("download_mbps", 0)
    ul = speed_data.get("upload_mbps", 0)

    # 下载速度慢
    if 0 < dl < 5:
        problems.append({
            "dimension": "carrier_fluctuation" if dl > 1 else "high_latency",
            "confidence": 0.7,
            "detail": f"下载速度 {dl:.1f} Mbps，"
                      f"{'低于正常水平' if dl > 1 else '非常慢'}",
            "evidence": {"download_mbps": dl},
        })

    # 上传速度慢
    if 0 < ul < 1:
        problems.append({
            "dimension": "carrier_fluctuation",
            "confidence": 0.5,
            "detail": f"上传速度 {ul:.2f} Mbps，视频通话可能受影响",
            "evidence": {"upload_mbps": ul},
        })

    return problems, len(problems)


def _get_fix_suggestions(problems: List[Dict]) -> List[Dict]:
    """
    根据诊断出的问题生成修复建议列表

    Args:
        problems: 诊断出的问题列表

    Returns:
        List[Dict]: 按优先级排序的修复建议
    """
    all_suggestions = []

    # 收集涉及的维度
    dims_seen = set()
    for p in problems:
        dim = p["dimension"]
        if dim in FIX_SUGGESTIONS and dim not in dims_seen:
            dims_seen.add(dim)
            suggestions = FIX_SUGGESTIONS[dim]

            # 对每个问题维度的建议添加优先级
            for i, suggestion in enumerate(suggestions):
                sug = {
                    "dimension": dim,
                    "priority": i + 1,
                    "action": suggestion["action"],
                    "steps": suggestion["steps"],
                    "expected_effect": suggestion["expected_effect"],
                    "problem_detail": p["detail"],
                    "confidence": p["confidence"],
                }
                all_suggestions.append(sug)

    # 按优先级排序 (先按问题置信度降序，再按建议序号升序)
    all_suggestions.sort(key=lambda s: (-s["confidence"], s["priority"]))

    return all_suggestions


def diagnose(test_results: Dict) -> Dict:
    """
    综合诊断入口 - 分析所有测试数据，输出诊断结论

    Args:
        test_results: 包含所有检测数据的字典
            {
                "ping": {...},
                "speed": {...},
                "signal": {...},
                "bandwidth": {...},
            }

    Returns:
        Dict: 诊断结果
            {
                "overall_health": str,          # 健康度 (优秀/良好/一般/较差/极差)
                "overall_score": int,            # 综合评分 0-100
                "problems": [...],               # 检测到的问题列表
                "fix_suggestions": [...],         # 修复建议（有序）
                "network_summary": {...},         # 网络信息摘要
                "timestamp": str,
            }
    """
    all_problems = []
    problem_counts = {}
    scores = []

    # --- 各维度分析 ---
    ping_data = test_results.get("ping", {})
    signal_data = test_results.get("signal", {})
    bandwidth_data = test_results.get("bandwidth", {})
    speed_data = test_results.get("speed", {})

    # 1. Ping 分析
    ping_problems, ping_count = _rate_ping(ping_data)
    all_problems.extend(ping_problems)
    problem_counts["ping"] = ping_count

    # 2. 信号分析
    signal_problems, signal_count = _rate_signal(signal_data)
    all_problems.extend(signal_problems)
    problem_counts["signal"] = signal_count

    # 3. 带宽分析
    bw_problems, bw_count = _rate_bandwidth(bandwidth_data)
    all_problems.extend(bw_problems)
    problem_counts["bandwidth"] = bw_count

    # 4. 测速分析
    speed_problems, speed_count = _rate_speed(speed_data)
    all_problems.extend(speed_problems)
    problem_counts["speed"] = speed_count

    # --- 综合评分 ---
    # 基础分 100
    base_score = 100

    # Ping 问题扣分
    p_summary = ping_data.get("summary", {})
    if p_summary.get("avg_latency_ms", 0) > 50:
        base_score -= (p_summary["avg_latency_ms"] - 50) * 0.15
    base_score -= p_summary.get("avg_loss_rate", 0) * 2
    base_score -= p_summary.get("max_jitter_ms", 0) * 0.3

    # 信号问题扣分
    wifi = signal_data.get("wifi", {})
    if wifi.get("signal_pct", 100) < 50:
        base_score -= (50 - wifi["signal_pct"]) * 0.5

    congestion = signal_data.get("channel_congestion", {})
    if congestion.get("score", 100) < 50:
        base_score -= (50 - congestion["score"]) * 0.3

    # 速度问题扣分
    dl = speed_data.get("download_mbps", 50)
    if 0 < dl < 20:
        base_score -= (20 - dl) * 1.5

    # 带宽问题扣分
    bw_grade = bandwidth_data.get("grade", {})
    base_score -= (100 - bw_grade.get("score", 100)) * 0.3

    # 限制评分范围
    overall_score = max(0, min(100, int(base_score)))

    # --- 健康度评级 ---
    if overall_score >= 90:
        health = "优秀"
        health_desc = "网络状态良好，无显著问题"
    elif overall_score >= 75:
        health = "良好"
        health_desc = "网络基本正常，存在小问题"
    elif overall_score >= 55:
        health = "一般"
        health_desc = "网络存在明显问题，建议排查"
    elif overall_score >= 30:
        health = "较差"
        health_desc = "网络质量差，影响正常使用"
    else:
        health = "极差"
        health_desc = "网络严重故障，需要立即解决"

    # --- 找出主要问题（置信度最高的问题） ---
    major_problems = sorted(
        all_problems, key=lambda p: p["confidence"], reverse=True
    )[:3]  # 最多显示前 3 个问题

    # --- 建议方案列表 ---
    fix_suggestions = _get_fix_suggestions(all_problems)

    # --- 网络摘要 ---
    network_type = signal_data.get("network_type", "未知")
    wifi_ssid = (signal_data.get("wifi", {}) or {}).get("ssid", "")

    network_summary = {
        "network_type": network_type,
        "wifi_ssid": wifi_ssid or "N/A",
        "avg_latency_ms": round(p_summary.get("avg_latency_ms", 0), 1),
        "download_mbps": speed_data.get("download_mbps", 0),
        "upload_mbps": speed_data.get("upload_mbps", 0),
        "signal_pct": wifi.get("signal_pct", 0),
        "health": health,
    }

    # --- 最终结果 ---
    result = {
        "overall_health": health,
        "overall_health_desc": health_desc,
        "overall_score": overall_score,
        "problems": all_problems,
        "major_problems": major_problems,
        "fix_suggestions": fix_suggestions,
        "network_summary": network_summary,
        "problem_counts": problem_counts,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    }

    print(f"\n{'='*50}")
    print(f"诊断结果: {health} ({overall_score}/100)")
    print(f"{'='*50}")
    if all_problems:
        print(f"发现 {len(all_problems)} 个问题:")
        for p in all_problems:
            dim_info = DIAGNOSIS_DIMENSIONS.get(p["dimension"], {})
            print(f"  {dim_info.get('icon', '•')} {dim_info.get('name', p['dimension'])}"
                  f" (置信度: {p['confidence']:.0%})")
            print(f"    {p['detail']}")
    else:
        print("√ 未检测到明显问题")

    if fix_suggestions:
        print(f"\n建议操作 ({len(fix_suggestions)} 条):")
        for s in fix_suggestions[:3]:
            print(f"  [{s['priority']}] {s['action']}")
            print(f"     预期效果: {s['expected_effect']}")

    return result


if __name__ == "__main__":
    print("=" * 50)
    print("诊断引擎模块 - 自测")
    print("=" * 50)

    # 模拟测试数据
    mock_results = {
        "ping": {
            "gateway": {"success": True, "latency_ms": {"avg": 150}, "jitter_ms": 40},
            "dns_servers": [
                {"name": "114 DNS", "success": True,
                 "latency_ms": {"avg": 45}, "dns_resolve_ms": 30,
                 "jitter_ms": 10},
                {"name": "谷歌 DNS", "success": True,
                 "latency_ms": {"avg": 180}, "dns_resolve_ms": 250,
                 "jitter_ms": 20},
            ],
            "summary": {"avg_latency_ms": 125, "max_jitter_ms": 40,
                        "avg_loss_rate": 0, "worst_loss_rate": 0},
        },
        "signal": {
            "network_type": "wifi",
            "wifi": {"connected": True, "ssid": "TestWiFi",
                     "signal_pct": 35, "rssi_dbm": -78},
            "channel_congestion": {"level": "拥挤", "score": 30,
                                   "description": "信道 6 有 12 个 AP"},
        },
        "bandwidth": {
            "grade": {"score": 45, "grade": "较差", "high_bw_apps": 3,
                      "suspicious_apps": 2, "description": ""},
            "suspicious_apps": [
                {"name": "xunlei.exe", "category": "download", "reason": ""},
                {"name": "svchost.exe", "category": "update", "reason": ""},
            ],
        },
        "speed": {
            "download_mbps": 8.5, "upload_mbps": 2.0,
        },
    }

    diagnose(mock_results)
