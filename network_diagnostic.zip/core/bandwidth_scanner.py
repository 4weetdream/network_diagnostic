"""
后台带宽占用扫描模块
Background bandwidth usage scanner

功能:
  - 扫描系统当前网络连接（TCP/UDP）
  - 按进程统计流量占用
  - 识别高带宽占用应用
  - 检测后台偷跑流量行为
  - 给出优化建议

平台兼容:
  - Windows: 使用 netstat + tasklist / PowerShell Get-NetAdapterStatistics
  - Linux/macOS: 使用 netstat / lsof + /proc 文件系统
  - Android: 通过 /proc/uid_stat 读取 (需 root) 或净流量估算

注意: 在非 root 的手机上获取单应用流量需使用 Android VPN API，
      本模块提供桌面端完整检测 + 移动端基础检测。
"""

import subprocess
import re
import time
import platform
import os
from typing import Dict, List, Optional
from collections import defaultdict


# 已知的高带宽应用/服务名单 (用于识别)
KNOWN_BANDWIDTH_APPS = {
    "cloud": ["cloud", "sync", "onedrive", "dropbox", "icloud",
              "baidunetdisk", "baiduply", "115"],
    "video": ["youtube", "netflix", "bilibili", "iqiyi", "tencentvideo",
              "youku", "mgtv", "douyin", "kuaishou"],
    "download": ["utorrent", "bt", "transmission", "aria2c", "xunlei",
                 "thunder", "qbittorrent", "fdm"],
    "game": ["steam", "epic", "origin", "lol", "valorant", "pubg",
             "wow", "overwatch", "fortnite", "王者荣耀", "原神"],
    "update": ["svchost", "wuauclt", "windowsupdate", "appstore",
               "playstore", "com.android.vending", "softwareupdate"],
    "social": ["wechat", "weixin", "qq", "tim", "dingtalk",
               "feishu", "lark", "telegram", "whatsapp", "skype"],
}


def get_network_connections() -> List[Dict]:
    """
    获取系统所有网络连接

    使用 netstat 命令获取当前 TCP/UDP 连接，
    包含本地/远程地址、状态、PID。

    Returns:
        List[Dict]: 连接列表
    """
    connections = []
    system = platform.system().lower()

    try:
        if system == "windows":
            # Windows: netstat -ano (显示 PID)
            output = subprocess.check_output(
                ["netstat", "-ano"], timeout=5,
                stderr=subprocess.DEVNULL, universal_newlines=True
            )

            for line in output.splitlines():
                fields = line.strip().split()
                if len(fields) >= 5:
                    # 识别协议
                    proto = fields[0]
                    if proto not in ("TCP", "UDP"):
                        continue

                    local = fields[1]
                    remote = fields[2] if len(fields) > 2 else ""
                    state = fields[3] if proto == "TCP" else ""
                    pid_idx = 4 if proto == "TCP" else 3
                    pid = fields[pid_idx] if len(fields) > pid_idx else ""

                    connections.append({
                        "protocol": proto, "local": local,
                        "remote": remote, "state": state,
                        "pid": pid,
                    })

        else:
            # Linux/macOS: netstat -tunp (需要适当权限)
            try:
                output = subprocess.check_output(
                    ["netstat", "-tunp"], timeout=5,
                    stderr=subprocess.DEVNULL, universal_newlines=True
                )
            except FileNotFoundError:
                # 试试 ss 命令
                output = subprocess.check_output(
                    ["ss", "-tunp"], timeout=5,
                    stderr=subprocess.DEVNULL, universal_newlines=True
                )

            for line in output.splitlines():
                fields = line.strip().split()
                if len(fields) >= 5:
                    proto = fields[0].lower()
                    if proto not in ("tcp", "udp", "tcp6", "udp6"):
                        continue
                    # 提取 PID
                    pid_match = re.search(r"pid=(\d+)", line)
                    pid = pid_match.group(1) if pid_match else ""
                    connections.append({
                        "protocol": proto.replace("6", ""),
                        "local": fields[3] if len(fields) > 3 else "",
                        "remote": fields[4] if len(fields) > 4 else "",
                        "state": fields[1] if proto == "tcp" else "",
                        "pid": pid,
                    })

    except subprocess.SubprocessError as e:
        print(f"[Bandwidth] 获取连接失败: {e}")

    return connections


def get_process_name(pid: str) -> str:
    """
    根据 PID 获取进程名称

    Args:
        pid: 进程 ID

    Returns:
        str: 进程名称
    """
    if not pid or pid == "0" or pid == "4":
        return "System" if pid == "4" else "Idle"

    system = platform.system().lower()

    try:
        if system == "windows":
            output = subprocess.check_output(
                ["tasklist", "/FI", f"PID eq {pid}", "/NH"],
                timeout=3, stderr=subprocess.DEVNULL,
                universal_newlines=True
            )
            # 解析输出: "chrome.exe 1234 Console 1 100,000 K"
            match = re.search(r"(\S+\.exe)\s", output)
            if match:
                return match.group(1)
            return f"PID:{pid}"

        elif system == "linux" or "android" in system:
            try:
                with open(f"/proc/{pid}/comm", "r") as f:
                    return f.read().strip()
            except (IOError, FileNotFoundError):
                try:
                    with open(f"/proc/{pid}/cmdline", "r") as f:
                        cmd = f.read().strip().replace("\0", " ")
                        return cmd.split("/")[-1].split(" ")[0] or f"PID:{pid}"
                except (IOError, FileNotFoundError):
                    return f"PID:{pid}"

        elif system == "darwin":
            output = subprocess.check_output(
                ["ps", "-p", str(pid), "-o", "comm="],
                timeout=3, stderr=subprocess.DEVNULL,
                universal_newlines=True
            )
            return output.strip() or f"PID:{pid}"

    except subprocess.SubprocessError:
        pass

    return f"PID:{pid}"


def classify_app(process_name: str) -> str:
    """
    根据进程名分类应用类型

    Returns:
        str: 分类 (cloud/video/download/game/update/social/other)
    """
    name_lower = process_name.lower()
    for category, keywords in KNOWN_BANDWIDTH_APPS.items():
        if any(kw in name_lower for kw in keywords):
            return category
    return "other"


def scan_bandwidth_usage() -> Dict:
    """
    扫描系统带宽使用情况

    通过分析网络连接数量和已知带宽特征，
    评估各进程的带宽占用。

    Returns:
        Dict: {
            "total_connections": int,
            "processes": [ {name, pid, connections, category, bandwidth_score} ],
            "high_bandwidth_apps": [ {name, category} ],
            "suspicious_apps": [ {name, reason} ],
            "timestamp": str
        }
    """
    result = {
        "total_connections": 0,
        "processes": [],
        "high_bandwidth_apps": [],
        "suspicious_apps": [],
        "background_downloads": [],
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    }

    # 1. 获取所有连接
    connections = get_network_connections()
    result["total_connections"] = len(connections)

    if not connections:
        result["note"] = "无法获取网络连接信息 (权限不足)"
        return result

    # 2. 按 PID 统计连接数
    pid_connections = defaultdict(list)
    for conn in connections:
        pid = conn.get("pid", "")
        if pid:
            pid_connections[pid].append(conn)

    # 3. 获取进程名并评估带宽占用
    processes = []
    for pid, conns in pid_connections.items():
        proc_name = get_process_name(pid)
        category = classify_app(proc_name)
        conn_count = len(conns)

        # 连接类型统计
        tcp_count = sum(1 for c in conns if c["protocol"] == "TCP")
        udp_count = sum(1 for c in conns if c["protocol"] == "UDP")
        established = sum(1 for c in conns if c.get("state") == "ESTABLISHED"
                          or c.get("state") == "CLOSE_WAIT")

        # 带宽占用评分 (0-100)
        # 基于连接数 + ESTABLISHED 连接比例 + 远端连接数
        remote_conns = sum(1 for c in conns
                          if ":" in c.get("remote", "")
                          and not c["remote"].startswith("127.")
                          and not c["remote"].startswith("0.0"))
        bw_score = min(100, int(
            conn_count * 5
            + established * 8
            + remote_conns * 3
        ))

        proc_info = {
            "name": proc_name,
            "pid": pid,
            "category": category,
            "connections": conn_count,
            "tcp": tcp_count,
            "udp": udp_count,
            "established": established,
            "remote_conns": remote_conns,
            "bandwidth_score": bw_score,
        }
        processes.append(proc_info)

    # 4. 按带宽占用排序
    processes.sort(key=lambda p: p["bandwidth_score"], reverse=True)
    result["processes"] = processes

    # 5. 识别高带宽占用应用
    high_bw_procs = [p for p in processes if p["bandwidth_score"] >= 30]
    for p in high_bw_procs:
        app = {
            "name": p["name"],
            "pid": p["pid"],
            "category": p["category"],
            "connections": p["connections"],
            "bandwidth_score": p["bandwidth_score"],
        }
        result["high_bandwidth_apps"].append(app)

    # 6. 识别可疑应用 (后台下载/更新/同步)
    suspicious_categories = {"download", "update", "cloud"}
    for p in processes:
        if p["category"] in suspicious_categories and p["connections"] >= 5:
            result["suspicious_apps"].append({
                "name": p["name"],
                "category": p["category"],
                "reason": (f"该应用有 {p['connections']} 个网络连接，"
                          f"可能在后台下载/同步数据"),
            })

        # 后台下载/更新特定识别
        if p["category"] == "download" and p["established"] >= 3:
            result["background_downloads"].append({
                "name": p["name"],
                "pid": p["pid"],
                "connections": p["connections"],
            })

    return result


def get_bandwidth_grades(scan_result: Dict) -> Dict:
    """
    评估带宽占用等级和建议

    Args:
        scan_result: scan_bandwidth_usage() 的输出

    Returns:
        Dict: 评估结果
    """
    high_bw = scan_result.get("high_bandwidth_apps", [])
    suspicious = scan_result.get("suspicious_apps", [])
    bg_dl = scan_result.get("background_downloads", [])
    total_conns = scan_result.get("total_connections", 0)

    # 评分: 越低越好 (带宽被占用越少)
    score = 100  # 满分100，扣分制

    if total_conns > 100:
        score -= 20
    elif total_conns > 50:
        score -= 10
    elif total_conns > 20:
        score -= 5

    # 高带宽应用扣分
    for app in high_bw:
        if app["bandwidth_score"] >= 60:
            score -= 15
        elif app["bandwidth_score"] >= 40:
            score -= 10
        else:
            score -= 5

    # 可疑应用额外扣分
    score -= len(suspicious) * 8
    score -= len(bg_dl) * 10

    score = max(0, min(100, score))

    # 等级
    if score >= 80:
        grade = "良好"
        desc = "系统带宽未被过度占用"
    elif score >= 60:
        grade = "一般"
        desc = f"存在 {len(high_bw)} 个高带宽应用，可能影响网络体验"
    elif score >= 30:
        grade = "较差"
        desc = f"检测到 {len(suspicious)} 个可疑后台应用，建议关闭"
    else:
        grade = "严重"
        desc = "大量后台应用占用带宽，网速可能严重受影响"

    return {
        "score": score,
        "grade": grade,
        "description": desc,
        "high_bw_apps": len(high_bw),
        "suspicious_apps": len(suspicious),
        "background_downloads": len(bg_dl),
    }


def run_bandwidth_scan() -> Dict:
    """
    执行完整的带宽扫描（便捷入口）

    Returns:
        Dict: 带宽扫描结果 + 等级评估
    """
    print("[Bandwidth] 开始扫描带宽占用...")

    scan_result = scan_bandwidth_usage()
    grades = get_bandwidth_grades(scan_result)

    # 合并结果
    scan_result["grade"] = grades

    # 输出摘要
    high_count = len(scan_result.get("high_bandwidth_apps", []))
    sus_count = len(scan_result.get("suspicious_apps", []))
    print(f"[Bandwidth] 总计 {scan_result.get('total_connections', 0)} 个连接, "
          f"{high_count} 个高带宽应用, "
          f"{sus_count} 个可疑应用")
    print(f"[Bandwidth] 带宽占用评分: {grades['score']}/100 ({grades['grade']})")

    return scan_result


if __name__ == "__main__":
    print("=" * 50)
    print("带宽占用扫描模块 - 自测")
    print("=" * 50)

    result = run_bandwidth_scan()
    print(f"\n总连接数: {result.get('total_connections')}")
    print("\n--- Top 5 带宽占用进程 ---")
    for p in result.get("processes", [])[:5]:
        print(f"  {p['name']:20s} | PID: {p['pid']:>5s} | "
              f"连接: {p['connections']:>3d} | "
              f"带宽评分: {p['bandwidth_score']}")
    if result.get("suspicious_apps"):
        print("\n--- 可疑应用 ---")
        for s in result["suspicious_apps"]:
            print(f"  ⚠ {s['name']}: {s['reason']}")
