"""
网络延迟与丢包检测模块
Network latency and packet loss detection module

功能:
  - Ping 网关延迟
  - Ping 公共 DNS (114.114.114.114, 8.8.8.8) 延迟
  - 数据包丢包率
  - 网络抖动 (Jitter) 计算
  - DNS 解析耗时

使用系统 ping 命令实现，跨平台兼容 (Windows/macOS/Linux/Android)
"""

import subprocess
import re
import time
import socket
import platform
from typing import Dict, List, Optional, Tuple


# 默认检测目标 (网关自动获取，DNS 手动指定)
DEFAULT_DNS_TARGETS = [
    {"name": "114 DNS", "host": "114.114.114.114"},
    {"name": "谷歌 DNS", "host": "8.8.8.8"},
    {"name": "阿里 DNS", "host": "223.5.5.5"},
]

# Ping 参数: 每个目标发 5 个包，超时 3 秒
PING_COUNT = 5
PING_TIMEOUT = 3  # seconds


def get_default_gateway() -> Optional[str]:
    """
    获取系统默认网关地址
    Get system default gateway address

    跨平台实现:
      - Windows: ipconfig 输出解析
      - Linux/macOS: route -n 或 ip route 输出解析
      - Android: /proc/net/route 解析
    """
    system = platform.system().lower()

    try:
        if system == "windows":
            # Windows: 从 ipconfig 中提取默认网关
            output = subprocess.check_output(
                ["ipconfig"], timeout=5, stderr=subprocess.DEVNULL,
                universal_newlines=True
            )
            # 匹配 "默认网关 . . . . . . . . . . . . : 192.168.x.x"
            for line in output.splitlines():
                if "默认网关" in line or "Default Gateway" in line:
                    gw = line.split(":")[-1].strip()
                    if gw and gw != "":
                        return gw
            return None

        elif system == "linux" or "android" in system:
            try:
                # 尝试 ip route
                output = subprocess.check_output(
                    ["ip", "route"], timeout=5, stderr=subprocess.DEVNULL,
                    universal_newlines=True
                )
                for line in output.splitlines():
                    if line.startswith("default via "):
                        return line.split()[2]
            except (subprocess.SubprocessError, FileNotFoundError):
                pass

            # 备选: /proc/net/route (Android 常用)
            try:
                with open("/proc/net/route", "r") as f:
                    for line in f.readlines()[1:]:  # 跳过表头
                        parts = line.strip().split()
                        if len(parts) >= 3 and parts[1] == "00000000":
                            # 网关地址是十六进制小端序
                            gw_hex = parts[2]
                            gw = ".".join(str(int(gw_hex[i:i+2], 16))
                                          for i in [6, 4, 2, 0])
                            return gw
            except (IOError, IndexError, ValueError):
                pass
            return None

        elif system == "darwin":
            # macOS: route -n get default
            output = subprocess.check_output(
                ["route", "-n", "get", "default"], timeout=5,
                stderr=subprocess.DEVNULL, universal_newlines=True
            )
            for line in output.splitlines():
                if "gateway:" in line:
                    gw = line.split(":")[-1].strip()
                    if gw:
                        return gw
            return None

    except subprocess.SubprocessError as e:
        print(f"[PingTester] 获取网关失败: {e}")
        return None

    return None


def _build_ping_command(target: str, count: int, timeout: int) -> List[str]:
    """
    根据操作系统构建 ping 命令
    Build ping command based on OS
    """
    system = platform.system().lower()

    if system == "windows":
        # Windows: ping -n <count> -w <timeout_ms> <target>
        return ["ping", "-n", str(count), "-w", str(timeout * 1000), target]
    else:
        # Linux/macOS/Android: ping -c <count> -W <timeout> <target>
        return ["ping", "-c", str(count), "-W", str(timeout), target]


def _parse_ping_output(output: str, system: str) -> Dict:
    """
    解析 ping 命令输出，提取延迟和丢包信息
    Parse ping command output to extract latency and loss

    返回格式:
    {
        "success": bool,        # 是否成功
        "sent": int,            # 发送包数
        "received": int,        # 接收包数
        "loss_rate": float,     # 丢包率 0.0 ~ 1.0
        "latency_ms": {         # 延迟统计 (毫秒)
            "min": float,
            "max": float,
            "avg": float,
            "mdev": float,      # 平均偏差 (抖动)
            "all": List[float]  # 所有个体延迟值
        },
        "jitter_ms": float      # 抖动值 (mdev 或标准差)
    }
    """
    result = {
        "success": False,
        "sent": PING_COUNT,
        "received": 0,
        "loss_rate": 1.0,
        "latency_ms": {"min": 0, "max": 0, "avg": 0, "mdev": 0, "all": []},
        "jitter_ms": 0,
    }

    # --- 1. 解析丢包率 ---
    loss_patterns = [
        r"(\d+)\s*%\s*(丢包|丢失|loss)",           # 中文 "50% 丢包"
        r"(\d+)\s*[\.\d]*%\s*packet loss",          # 英文 "50% packet loss"
        r"Lost\s*=\s*(\d+)",                         # Windows "Lost = 2"
    ]
    for pattern in loss_patterns:
        match = re.search(pattern, output, re.IGNORECASE)
        if match:
            try:
                loss_pct = float(match.group(1))
                result["loss_rate"] = loss_pct / 100.0
            except ValueError:
                pass
            break

    # --- 2. 用 "Received = X" (Windows) 推算收发数 ---
    recv_match = re.search(r"[Rr]eceived\s*=\s*(\d+)", output)
    if recv_match:
        result["received"] = int(recv_match.group(1))
        sent_match = re.search(r"[Ss]ent\s*=\s*(\d+)", output)
        if sent_match:
            result["sent"] = int(sent_match.group(1))

    # --- 3. 提取所有个体延迟 ---
    # 匹配 "time=XXms" 或 "time=XX ms" 或 "<XX ms" (Windows)
    all_latencies = []
    time_patterns = [
        r"time[=~<]\s*([\d.]+)\s*ms",
        r"time[=~<]\s*([\d.]+)\s*milliseconds",
        r"([\d.]+)\s*ms\s*(?:$|[\(\)\w])",
    ]
    for pattern in time_patterns:
        matches = re.findall(pattern, output, re.IGNORECASE)
        for m in matches:
            try:
                val = float(m)
                if 0 < val < 30000:  # 过滤异常值 (>30s 丢弃)
                    all_latencies.append(val)
            except ValueError:
                pass

    # 去重(匹配可能重复)
    all_latencies = list(set(round(v, 2) for v in all_latencies))
    all_latencies.sort()

    if all_latencies:
        result["latency_ms"]["all"] = all_latencies
        result["latency_ms"]["min"] = min(all_latencies)
        result["latency_ms"]["max"] = max(all_latencies)
        result["latency_ms"]["avg"] = sum(all_latencies) / len(all_latencies)

        # --- 4. 计算抖动 (Jitter) ---
        if len(all_latencies) >= 2:
            # RFC 3550 jitter: 连续延迟差值的平均
            diffs = [abs(all_latencies[i] - all_latencies[i - 1])
                     for i in range(1, len(all_latencies))]
            jitter = sum(diffs) / len(diffs)
            result["jitter_ms"] = round(jitter, 2)
            result["latency_ms"]["mdev"] = round(
                (sum((v - result["latency_ms"]["avg"]) ** 2 for v in all_latencies)
                 / len(all_latencies)) ** 0.5, 2
            )

        result["received"] = len(all_latencies)

    # --- 5. 计算丢包率（如果尚未通过 loss% 行获取） ---
    if result["loss_rate"] == 1.0 and result["sent"] > 0:
        result["loss_rate"] = round(
            (result["sent"] - result["received"]) / result["sent"], 2
        )

    result["success"] = result["received"] > 0
    return result


def ping_host(target: str, name: str = "",
              count: int = PING_COUNT,
              timeout: int = PING_TIMEOUT) -> Dict:
    """
    对单个目标执行 ping 检测
    Ping a single target host

    Args:
        target: IP 地址或域名
        name: 目标名称（用于显示）
        count: 发送包数
        timeout: 超时秒数

    Returns:
        Dict: 包含目标信息和检测结果
    """
    system = platform.system().lower()
    cmd = _build_ping_command(target, count, timeout)

    full_result = {
        "target": target,
        "name": name or target,
        "ip": target,
        "type": "gateway" if name == "网关" else "dns",
    }

    try:
        start_time = time.time()
        output = subprocess.check_output(
            cmd, timeout=timeout + 2, stderr=subprocess.STDOUT,
            universal_newlines=True
        )
        elapsed = time.time() - start_time

        parsed = _parse_ping_output(output, system)
        full_result.update(parsed)
        full_result["dns_resolve_ms"] = 0  # DNS 解析时间单独测量

        print(f"[Ping] {name or target}: "
              f"avg={parsed['latency_ms']['avg']:.1f}ms, "
              f"loss={parsed['loss_rate']*100:.0f}%, "
              f"jitter={parsed['jitter_ms']:.1f}ms "
              f"(in {elapsed:.1f}s)")

    except subprocess.TimeoutExpired:
        full_result.update({
            "success": False, "sent": count, "received": 0,
            "loss_rate": 1.0,
            "latency_ms": {"min": 0, "max": 0, "avg": 0, "mdev": 0, "all": []},
            "jitter_ms": 0, "error": "Ping 超时",
        })
        print(f"[Ping] {name or target}: 超时 (>{timeout}s)")

    except subprocess.CalledProcessError as e:
        # 非零退出码也可能是正常结果（如丢包 > 0）
        output = e.output if isinstance(e.output, str) else ""
        parsed = _parse_ping_output(output, system)
        full_result.update(parsed)
        if not parsed["success"] and parsed["loss_rate"] == 0:
            full_result["error"] = f"Ping 执行失败: {e}"
        print(f"[Ping] {name or target}: "
              f"avg={parsed['latency_ms']['avg']:.1f}ms, "
              f"loss={parsed['loss_rate']*100:.0f}%")

    except FileNotFoundError:
        full_result.update({
            "success": False, "error": "系统中未找到 ping 命令",
            "loss_rate": 1.0,
        })
        print(f"[Ping] 错误: 未找到 ping 命令")

    return full_result


def measure_dns_resolution(host: str) -> float:
    """
    测量 DNS 解析耗时 (毫秒)
    Measure DNS resolution time

    Args:
        host: 域名

    Returns:
        float: 解析耗时(ms)，失败返回 -1
    """
    try:
        start = time.time()
        socket.getaddrinfo(host, 80, socket.AF_INET)
        elapsed = (time.time() - start) * 1000  # 转毫秒
        return round(elapsed, 2)
    except (socket.gaierror, OSError) as e:
        print(f"[DNS] 解析 {host} 失败: {e}")
        return -1


def run_all_ping_tests(gateway_ip: Optional[str] = None) -> Dict:
    """
    执行全套 ping 检测
    Run all ping tests (gateway + DNS targets)

    Args:
        gateway_ip: 网关 IP（为 None 则自动获取）

    Returns:
        Dict: 所有检测结果汇总
    """
    # 1. 获取网关
    if gateway_ip is None:
        gateway_ip = get_default_gateway()

    results = {
        "gateway": None,
        "dns_servers": [],
        "dns_resolve": {},
        "summary": {},
    }

    targets = []

    # 2. 添加网关目标
    if gateway_ip:
        targets.append({"target": gateway_ip, "name": "网关", "type": "gateway"})
        results["gateway_ip"] = gateway_ip
    else:
        print("[Ping] 未检测到默认网关，跳过网关 ping")

    # 3. 添加 DNS 目标
    for dns in DEFAULT_DNS_TARGETS:
        targets.append({
            "target": dns["host"], "name": dns["name"], "type": "dns"
        })

    # 4. 全量检测 (含 DNS 解析延时测量)
    for t in targets:
        ping_result = ping_host(t["target"], t["name"])
        ping_result["type"] = t["type"]

        if t["type"] == "dns":
            # 测量该 DNS 服务器解析常用域名的耗时
            resolve_times = {}
            for domain in ["www.baidu.com", "www.qq.com", "www.taobao.com"]:
                rt = measure_dns_resolution(domain)
                if rt > 0:
                    resolve_times[domain] = rt
            ping_result["dns_resolve_ms"] = (
                sum(resolve_times.values()) / len(resolve_times)
                if resolve_times else 0
            )

        if t["type"] == "gateway":
            results["gateway"] = ping_result
        else:
            results["dns_servers"].append(ping_result)

    # 5. 汇总统计
    all_success = [r for r in [results["gateway"]] + results["dns_servers"]
                   if r and r.get("success")]
    all_avg_latencies = [r["latency_ms"]["avg"] for r in all_success]
    all_jitters = [r["jitter_ms"] for r in all_success]
    all_loss = [r["loss_rate"] * 100 for r in [results["gateway"]]
                + results["dns_servers"] if r]

    results["summary"] = {
        "targets_tested": len(targets),
        "targets_ok": len(all_success),
        "avg_latency_ms": (sum(all_avg_latencies) / len(all_avg_latencies)
                           if all_avg_latencies else 0),
        "max_jitter_ms": max(all_jitters) if all_jitters else 0,
        "avg_loss_rate": (sum(all_loss) / len(all_loss) if all_loss else 0),
        "worst_loss_rate": max(all_loss) if all_loss else 0,
    }

    return results


if __name__ == "__main__":
    # 独立测试该模块
    print("=" * 50)
    print("网络延迟检测模块 - 自测")
    print("=" * 50)
    gw = get_default_gateway()
    print(f"默认网关: {gw or '未获取到'}")
    print()

    results = run_all_ping_tests(gw)

    print()
    print("--- 检测结果汇总 ---")
    for key, val in results.get("summary", {}).items():
        unit = "ms" if "ms" in key else "%" if "rate" in key else ""
        print(f"  {key}: {val:.1f}{unit}")
