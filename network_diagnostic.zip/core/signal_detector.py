"""
信号强度与信道检测模块
Signal strength and channel detection module

功能:
  - WiFi 信号强度 (RSSI) 检测
  - WiFi 信道拥挤度评估
  - 蜂窝网络信号强度 (通过系统 API)
  - 网络连接类型识别 (4G/5G/WiFi)
  - 基站连接状态信息

平台兼容:
  - Windows: 使用 netsh wlan 命令
  - Linux: 使用 iwconfig / iw 命令
  - Android: 通过 /proc/net 或系统属性获取
  - iOS/macOS: 使用机场工具 / System Preferences
"""

import subprocess
import re
import platform
import socket
import struct
import time
from typing import Dict, List, Optional, Tuple


# ============================================================
# 工具函数
# ============================================================
def _run_cmd(cmd: List[str], timeout: int = 5) -> str:
    """安全执行命令并返回输出"""
    try:
        return subprocess.check_output(
            cmd, timeout=timeout, stderr=subprocess.DEVNULL,
            universal_newlines=True
        )
    except (subprocess.SubprocessError, FileNotFoundError, OSError):
        return ""


# ============================================================
# WiFi 信号检测
# ============================================================
def get_wifi_info_windows() -> Dict:
    """
    Windows: 通过 netsh wlan 获取 WiFi 信息
    包括 SSID、信号强度、频段、信道等
    """
    info = {
        "enabled": False, "connected": False,
        "ssid": "", "signal_pct": 0, "rssi_dbm": 0,
        "channel": 0, "frequency_ghz": 0,
        "bssid": "", "link_speed_mbps": 0,
    }

    # 获取接口信息
    output = _run_cmd(["netsh", "wlan", "show", "interfaces"])
    if not output:
        return info

    info["enabled"] = True

    # 解析字段
    patterns = {
        "ssid": [r"SSID\s*[: ]\s*(.+)", r"配置文件\s*[: ]\s*(.+)"],
        "signal_pct": [r"信号\s*[: ]\s*(\d+)%"],
        "channel": [r"信道\s*[: ]\s*(\d+)"],
        "frequency_ghz": [r"频率\s*[: ]\s*([\d.]+)\s*GHz"],
        "bssid": [r"BSSID\s*[: ]\s*([\da-fA-F:-]+)"],
        "link_speed_mbps": [r"速度\s*[: ]\s*([\d.]+)\s*Mbps"],
    }

    for key, p_list in patterns.items():
        for p in p_list:
            match = re.search(p, output)
            if match:
                val = match.group(1).strip()
                if key == "signal_pct":
                    sig_val = int(val)
                    info["signal_pct"] = sig_val
                    # 估算 RSSI (百分比转 dBm 近似)
                    info["rssi_dbm"] = int(sig_val / 100 * 90 - 100)
                elif key == "channel":
                    info["channel"] = int(val)
                elif key == "frequency_ghz":
                    info["frequency_ghz"] = float(val)
                elif key == "link_speed_mbps":
                    info["link_speed_mbps"] = int(float(val))
                else:
                    info[key] = val
                break

    if info["ssid"]:
        info["connected"] = True

    return info


def get_wifi_info_linux() -> Dict:
    """
    Linux/Android: 通过 iwconfig / iw 获取 WiFi 信息
    """
    info = {
        "enabled": False, "connected": False,
        "ssid": "", "signal_pct": 0, "rssi_dbm": 0,
        "channel": 0, "frequency_ghz": 0,
        "bssid": "", "link_speed_mbps": 0,
    }

    # 尝试 iwconfig
    output = _run_cmd(["iwconfig"])
    if not output or "no wireless" in output.lower():
        # 尝试 iw dev 命令
        dev_output = _run_cmd(["iw", "dev"])
        if not dev_output:
            return info

        # 找到第一个无线接口
        iface_match = re.search(r"Interface\s+(\w+)", dev_output)
        if not iface_match:
            return info
        iface = iface_match.group(1)

        # iw link 获取连接信息
        link_out = _run_cmd(["iw", "dev", iface, "link"])
        if link_out:
            info["enabled"] = True
            ssid_m = re.search(r"SSID:\s*(.+)", link_out)
            if ssid_m:
                info["ssid"] = ssid_m.group(1).strip()
                info["connected"] = True

            signal_m = re.search(r"signal:\s*(-?\d+)\s*dBm", link_out)
            if signal_m:
                info["rssi_dbm"] = int(signal_m.group(1))
                # dBm 转百分比 (近似: -30 ~ -100 dBm)
                info["signal_pct"] = max(0, min(100,
                    int((info["rssi_dbm"] + 100) / 70 * 100)))

            freq_m = re.search(r"freq:\s*([\d.]+)", link_out)
            if freq_m:
                info["frequency_ghz"] = round(float(freq_m.group(1)) / 1000, 2)
                # 频率转信道 (2.4GHz 近似)
                if 2.4 <= info["frequency_ghz"] <= 2.5:
                    freq_mhz = float(freq_m.group(1))
                    info["channel"] = int((freq_mhz - 2412) / 5 + 1)
                elif 5 <= info["frequency_ghz"] <= 6:
                    info["channel"] = int(float(freq_mhz) / 5 - 1000)

            # 速率
            rate_m = re.search(r"tx bitrate:\s*([\d.]+)\s*MBit/s", link_out)
            if rate_m:
                info["link_speed_mbps"] = int(float(rate_m.group(1)))
    else:
        # 解析 iwconfig 输出
        info["enabled"] = True

        # ESSID
        ssid_m = re.search(r'ESSID:"(.+?)"', output)
        if ssid_m:
            info["ssid"] = ssid_m.group(1)
            info["connected"] = True

        # 信号质量 / 信号强度
        qual_m = re.search(r"Link Quality=(\d+)/(\d+)", output)
        if qual_m:
            info["signal_pct"] = int(int(qual_m.group(1)) / int(qual_m.group(2)) * 100)

        level_m = re.search(r"Signal level=(-?\d+)\s*dBm", output)
        if level_m:
            info["rssi_dbm"] = int(level_m.group(1))

        # 频率 / 信道
        freq_m = re.search(r"Frequency[:=]([\d.]+)\s*(GHz|MHz)", output)
        if freq_m:
            val = float(freq_m.group(1))
            info["frequency_ghz"] = val if "G" in freq_m.group(2) else val / 1000

    return info


def scan_wifi_channels() -> List[Dict]:
    """
    扫描周围 WiFi 网络，评估信道拥挤度

    Returns:
        List[Dict]: 各信道 AP 数量统计
    """
    channels = {}  # channel -> {"ap_count": n, "ssids": []}
    system = platform.system().lower()

    if system == "windows":
        output = _run_cmd(["netsh", "wlan", "show", "networks", "mode=bssid"])
        if not output:
            return []

        # 解析每个网络的 BSSID 信息
        current_ssid = ""
        for line in output.splitlines():
            ssid_m = re.match(r"^SSID\s+\d+\s*:\s*(.+)", line)
            if ssid_m:
                current_ssid = ssid_m.group(1).strip()
                continue

            ch_m = re.search(r"信道\s*[: ]\s*(\d+)", line)
            if ch_m and current_ssid:
                ch = int(ch_m.group(1))
                if ch not in channels:
                    channels[ch] = {"ap_count": 0, "ssids": []}
                channels[ch]["ap_count"] += 1
                if current_ssid not in channels[ch]["ssids"]:
                    channels[ch]["ssids"].append(current_ssid)

    elif system == "linux" or "android" in system:
        # 使用 iw dev scan 或 iwlist
        # 简化：使用 iwlist
        iface = ""
        dev_out = _run_cmd(["iw", "dev"])
        if dev_out:
            iface_m = re.search(r"Interface\s+(\w+)", dev_out)
            if iface_m:
                iface = iface_m.group(1)

        if iface:
            scan_out = _run_cmd(["iwlist", iface, "scan"], timeout=10)
            if scan_out:
                current_bssid = ""
                for line in scan_out.splitlines():
                    ch_m = re.search(r"Channel[:\s]*(\d+)", line)
                    if ch_m:
                        ch = int(ch_m.group(1))
                        if ch not in channels:
                            channels[ch] = {"ap_count": 0, "ssids": []}
                        channels[ch]["ap_count"] += 1

    # 信道拥挤度评估
    result = []
    for ch, data in sorted(channels.items(), key=lambda x: x[0]):
        ap = data["ap_count"]
        if ap <= 2:
            congestion = "空闲"
        elif ap <= 5:
            congestion = "适中"
        elif ap <= 10:
            congestion = "拥挤"
        else:
            congestion = "非常拥挤"

        result.append({
            "channel": ch,
            "ap_count": ap,
            "congestion": congestion,
            "ssids": data["ssids"][:5],  # 最多显示 5 个
        })

    return result


def evaluate_channel_congestion(channel_info: List[Dict]) -> Dict:
    """
    评估总信道拥挤度
    考虑当前连接信道和整体环境

    Returns:
        Dict: 拥挤度评分和描述
    """
    if not channel_info:
        return {
            "score": 0, "level": "未知",
            "description": "无法扫描周围网络环境"
        }

    total_ap = sum(c["ap_count"] for c in channel_info)
    avg_ap_per_ch = total_ap / max(len(channel_info), 1)

    if avg_ap_per_ch <= 2:
        return {"score": 90, "level": "空闲",
                "description": f"周围共 {total_ap} 个 AP，信道环境良好"}
    elif avg_ap_per_ch <= 4:
        return {"score": 65, "level": "一般",
                "description": f"周围共 {total_ap} 个 AP，部分信道拥挤"}
    elif avg_ap_per_ch <= 8:
        return {"score": 35, "level": "拥挤",
                "description": f"周围共 {total_ap} 个 AP，建议切换信道"}
    else:
        return {"score": 15, "level": "非常拥挤",
                "description": f"周围共 {total_ap} 个 AP，WiFi 干扰严重"}


# ============================================================
# 蜂窝网络检测（简化版）
# ============================================================
def get_cellular_info() -> Dict:
    """
    获取蜂窝网络信息

    手机端通过系统 API 或系统属性读取，
    桌面端返回空信息。

    注意: 在 Android 上需要通过 PyJNIus 或
    Android 系统属性访问，纯 Python 方案受限。
    """
    info = {
        "available": False,
        "type": "",           # 4G / 5G / 3G / 未知
        "signal_bars": 0,     # 信号格数 (0-5)
        "operator": "",       # 运营商
        "mcc_mnc": "",        # MCC-MNC 编码
    }

    system = platform.system().lower()

    # Android 系统属性读取 (需要 adb 或 root)
    android_props = [
        "gsm.operator.alpha",        # 运营商名称
        "gsm.operator.numeric",      # MCC-MNC
        "gsm.network.type",          # 网络类型
        "gsm.signal.strength",       # 信号强度
    ]

    if "android" in system:
        # 尝试通过 getprop 命令读取
        for prop in android_props:
            val = _run_cmd(["getprop", prop]).strip()
            if val:
                info["available"] = True
                if prop == "gsm.operator.alpha":
                    info["operator"] = val
                elif prop == "gsm.operator.numeric":
                    info["mcc_mnc"] = val
                elif prop == "gsm.network.type":
                    info["type"] = _map_network_type(val)

    # Windows / Linux 桌面: 通常没有蜂窝信息
    # 可通过 WMI (Windows) 或 ModemManager 尝试
    if system == "windows":
        # 检查是否有移动宽带适配器
        output = _run_cmd([
            "powershell", "-Command",
            "Get-NetAdapter | Where-Object {$_.Name -like '*Mobile*' -or "
            "$_.InterfaceDescription -like '*LTE*'} | "
            "Select-Object Name,Status,LinkSpeed | ConvertTo-Json"
        ])
        if output and "Name" in output:
            info["available"] = True

    return info


def _map_network_type(net_type: str) -> str:
    """映射 Android 网络类型代码为可读名称"""
    mapping = {
        "LTE": "4G", "eHRPD": "3G", "HSPAP": "3.5G",
        "NR": "5G", "GPRS": "2.5G", "EDGE": "2.75G",
        "UMTS": "3G", "HSPA": "3.5G", "HSDPA": "3.5G",
        "HSUPA": "3.5G", "1xRTT": "2G", "CDMA": "2G",
        "EVDO_0": "3G", "EVDO_A": "3G", "EVDO_B": "3G",
    }
    for key, val in mapping.items():
        if key.lower() in net_type.lower():
            return val
    if "13" in net_type or "LTE" in net_type.upper():
        return "4G"
    if "20" in net_type:
        return "5G"
    return net_type


# ============================================================
# 综合检测入口
# ============================================================
def detect_network_type() -> str:
    """
    检测当前网络连接类型

    Returns:
        str: wifi / cellular_4g / cellular_5g / cellular_other / unknown
    """
    system = platform.system().lower()

    if system == "windows":
        info = get_wifi_info_windows()
    else:
        info = get_wifi_info_linux()

    if info.get("connected"):
        return "wifi"

    # 检查蜂窝网络
    cell = get_cellular_info()
    if cell.get("available"):
        net_type = cell.get("type", "")
        if "5G" in net_type:
            return "cellular_5g"
        elif "4G" in net_type:
            return "cellular_4g"
        else:
            return "cellular_other"

    # 通过 ping 外部 IP 判断是否有网
    try:
        socket.create_connection(("114.114.114.114", 53), timeout=2)
        return "unknown_connected"
    except OSError:
        return "disconnected"


def run_all_signal_tests() -> Dict:
    """
    执行全套信号检测

    Returns:
        Dict: 综合信号检测结果
    """
    system = platform.system().lower()
    results = {
        "network_type": "",
        "wifi": {},
        "cellular": {},
        "channel_analysis": [],
        "channel_congestion": {},
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    }

    # 1. 检测网络类型
    results["network_type"] = detect_network_type()
    print(f"[Signal] 网络类型: {results['network_type']}")

    # 2. WiFi 信息
    if "wifi" in results["network_type"]:
        if system == "windows":
            wifi_info = get_wifi_info_windows()
        else:
            wifi_info = get_wifi_info_linux()
        results["wifi"] = wifi_info

        # WiFi 信号评分
        signal = wifi_info.get("signal_pct", 0)
        if signal >= 80:
            results["wifi"]["signal_grade"] = "强"
        elif signal >= 55:
            results["wifi"]["signal_grade"] = "良好"
        elif signal >= 30:
            results["wifi"]["signal_grade"] = "弱"
        else:
            results["wifi"]["signal_grade"] = "极弱"

        print(f"[Signal] WiFi SSID: {wifi_info.get('ssid')}, "
              f"信号: {signal}% ({wifi_info.get('rssi_dbm')}dBm)")

        # 3. 信道扫描
        channels = scan_wifi_channels()
        results["channel_analysis"] = channels
        results["channel_congestion"] = evaluate_channel_congestion(channels)
        print(f"[Signal] 信道拥挤度: "
              f"{results['channel_congestion'].get('level')}")

    else:
        # 蜂窝网络信息
        cell_info = get_cellular_info()
        results["cellular"] = cell_info
        print(f"[Signal] 蜂窝网络: {cell_info.get('type')} "
              f"{cell_info.get('operator')}")

    return results


if __name__ == "__main__":
    print("=" * 50)
    print("信号检测模块 - 自测")
    print("=" * 50)

    result = run_all_signal_tests()

    print(f"\n网络类型: {result['network_type']}")
    if result.get("wifi"):
        w = result["wifi"]
        print(f"WiFi: {w.get('ssid')} | 信号: {w.get('signal_pct')}% "
              f"({w.get('signal_grade')}) | "
              f"信道: {w.get('channel')} | 速率: {w.get('link_speed_mbps')}Mbps")
    if result.get("cellular"):
        c = result["cellular"]
        print(f"蜂窝: {c.get('type')} {c.get('operator')}")
    if result.get("channel_congestion"):
        cc = result["channel_congestion"]
        print(f"信道拥挤: {cc.get('level')} ({cc.get('description')})")
