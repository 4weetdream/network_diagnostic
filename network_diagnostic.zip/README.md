# 📱 手机端网络卡顿自查检测工具

轻量级手机网络诊断工具，纯 Python 实现，基于 Kivy 跨平台框架。

## ✨ 功能特性

| 检测模块 | 检测项 | 说明 |
|---------|--------|------|
| **📡 基础网络** | 实时测速 | HTTP 下载/上传速度测试 |
| | Ping 延迟 | 网关 + 公共 DNS (114/8.8) 延迟 |
| | 丢包率 | 数据包丢失百分比 |
| | 网络抖动 | 延迟稳定性 (Jitter) |
| **📶 信号检测** | WiFi 信号强度 | RSSI dBm 数值 + 百分比 |
| | 信道拥挤度 | 周围 WiFi AP 数量 + 拥挤评级 |
| | 蜂窝网络 | 网络类型 (4G/5G)、运营商 |
| **⚡ 带宽扫描** | 连接统计 | TCP/UDP 连接数 |
| | 应用识别 | 按进程分类高带宽应用 |
| | 后台检测 | 识别偷跑流量/自动更新 |
| **🔍 故障诊断** | 智能分析 | 7 维度加权诊断引擎 |
| | 根因定位 | DNS/信号/带宽/延迟等 |
| | 一键解决 | 带操作步骤的修复建议 |

## 📂 项目结构

```
network_diagnostic/
├── main.py                    # 主程序入口 (Kivy App)
├── app.kv                     # Kivy UI 布局文件
├── requirements.txt           # Python 依赖
├── README.md                  # 本文件
├── core/                      # 核心检测模块
│   ├── __init__.py
│   ├── ping_tester.py         # Ping / 延迟 / 丢包 / 抖动
│   ├── speed_tester.py        # 下载 / 上传测速
│   ├── signal_detector.py     # WiFi / 蜂窝信号检测
│   ├── bandwidth_scanner.py   # 后台带宽占用扫描
│   ├── diagnosis_engine.py    # 智能诊断引擎
│   ├── report_generator.py    # HTML 图文报告
│   └── orchestrator.py        # 流程编排器
└── ui/                        # UI 组件
    ├── __init__.py
    └── app.kv                 # 布局样式
```

## 🚀 部署运行

### 1. 桌面端开发/调试

```bash
# 1. 安装 Python 3.8+
# 下载: https://www.python.org/downloads/

# 2. 安装依赖
pip install kivy kivymd

# 3. 运行应用
cd network_diagnostic
python main.py
```

### 2. Android 手机部署

**方法 A: Buildozer 打包 (推荐)**

```bash
# 1. 安装 Buildozer
pip install buildozer

# 2. 在项目目录初始化 Buildozer
cd network_diagnostic
buildozer init

# 3. 编辑 buildozer.spec，修改关键配置:
#    title = 网络诊断
#    package.name = networkdiag
#    package.domain = org.example.networkdiag
#    requirements = python3,kivy,kivymd
#    android.permissions = INTERNET,ACCESS_WIFI_STATE,ACCESS_NETWORK_STATE
#    android.api = 31
#    android.minapi = 21

# 4. 打包 APK (首次需要下载 SDK/NDK，耗时较长)
buildozer android debug

# 5. APK 文件位置: bin/networkdiag-0.1-*-debug.apk
#    复制到手机安装即可
```

**方法 B: 使用 Python-for-Android**

```bash
# 需要 Linux 环境 (WSL/Ubuntu)
git clone https://github.com/kivy/python-for-android
cd python-for-android

# 编译 APK
./build.py --name "网络诊断" \
  --package org.example.networkdiag \
  --version 1.0 \
  --private ../network_diagnostic \
  --requirements python3,kivy,kivymd \
  --permission INTERNET \
  --permission ACCESS_WIFI_STATE \
  --permission ACCESS_NETWORK_STATE \
  --arch arm64-v8a \
  debug
```

**方法 C: 使用 Termux (无需打包，直接运行)**

```bash
# 1. 安装 Termux (F-Droid 版，非 Play 版)
#    下载: https://f-droid.org/packages/com.termux/

# 2. 安装 Python 和 Kivy
pkg update && pkg upgrade
pkg install python git clang python-pip libjpeg-turbo main.devel.python-libxml2
pip install kivy kivymd

# 3. 克隆项目
git clone https://github.com/your-repo/network_diagnostic.git
cd network_diagnostic

# 4. 运行
python main.py

# Termux 注意事项:
# - 需安装 termux-x11 或使用 SDL 子系统和 VNC 来显示 GUI
# - Kivy 在 Termux 中需要 SDL2 后端
# 推荐方案: pkg install x11-repo && pkg install termux-x11-nightly
```

### 3. iOS 部署

```bash
# 需要 macOS + Xcode
# 使用 kivy-ios 工具链

# 1. 安装工具链
git clone https://github.com/kivy/kivy-ios
cd kivy-ios

# 2. 编译 Python 和依赖
python toolchain.py build python3 kivy

# 3. 创建 Xcode 项目
python toolchain.py create \
  --name "网络诊断" \
  --package org.example.networkdiag \
  --app-class NetworkDiagApp \
  ~/path/to/network_diagnostic

# 4. 用 Xcode 打开并部署到 iPhone
open network-diagnostic-ios/network-diagnostic.xcodeproj
```

## 📱 界面预览

```
┌─────────────────────┐
│   网络诊断工具        │
├─────────────────────┤
│                     │
│   📱 网络卡顿自检    │
│  一键检测网络延迟、   │
│  信号强度、带宽占用   │
│                     │
│  [🚀 开始全面检测]    │
│                     │
│ ┌─────┬─────┬─────┐ │
│ │测速 │信号 │Ping │ │
│ └─────┴─────┴─────┘ │
│                     │
│   📋 上次检测结果     │
│ 健康度: 良好(82/100) │
│                     │
│   🔍 检测项目说明    │
│   • 基础网络...      │
│   • 信号检测...      │
└─────────────────────┘
```

## ⚠️ 已知限制

| 限制项 | 说明 |
|-------|------|
| **iOS 信号检测** | 无法从 Python 获取 iPhone 蜂窝信号强度 (系统 API 限制) |
| **Android 单 App 流量** | 非 root 设备无法获取单个 App 确切流量 (需 VPN API) |
| **后台扫描** | 带宽扫描基于 netstat 连接估算，非精确流量计量 |
| **速度测试** | 受测速服务器位置和网络状况影响，存在 ±20% 误差 |

## 🔧 平台兼容性

| 平台 | Ping | 测速 | WiFi信号 | 蜂窝信号 | 带宽扫描 |
|-----|------|------|---------|---------|---------|
| Windows | ✅ | ✅ | ✅ (netsh) | ❌ | ✅ |
| Linux | ✅ | ✅ | ✅ (iwconfig) | ❌ | ✅ |
| Android | ✅ | ✅ | ✅ (iw) | ⚠️ (getprop) | ⚠️ |
| macOS | ✅ | ✅ | ⚠️ | ❌ | ✅ |
| iOS | ✅ | ✅ | ❌ | ❌ | ❌ |

## 📄 许可

MIT License

## 🤝 贡献

欢迎提交 Issue 和 PR！改进方向:
- 添加更多测速服务器节点
- 增强 Android 信号检测 (PyJNIus)
- 支持 iOS 更多检测项
- 添加 VPN API 实现精确流量统计
